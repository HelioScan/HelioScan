G# StarUML Plug-in
Version: 1.2.1
April 15th, 2011

The G# StarUML Plug-in is a plug-in to the G# Framework and also to the free, open source UML tool, StarUML. It integrates into StarUML making it really easy to design and maintain the LabVIEW G# code in a professional UML design tool. The plug-in supports both code generating from StarUML to LabVIEW G# classes and also reversed engineering from a LabVIEW project containing G# classes to visualing the classes and their dependencies in a UML class diagram in StarUML. All actions are performed in the StarUML development environment. The G# StarUML Plug-in is a National Instrument Compatible with LabVIEW Silver product.

Copyright � 2010, AddQ Consulting, www.addq.se
All rights reserved. G# is a registered trademark of AddQ Consulting.

The �COMPATIBLE WITH LABVIEW� logo is a trademark of National Instruments Corporation and is used under a license from National Instruments Corporation. The G# StarUML Plug-in software program is a product of AddQ Consulting, not National Instruments Corporation, and AddQ Consulting is solely responsible for the G# StarUML Plug-in software program. Neither AddQ Consulting, nor any of the software programs and other goods and services offered by AddQ Consulting, are affiliated with, endorsed by or sponsored by National Instruments Corporation.

## SUPPORTED VERSIONS AND DEPENDENCIES ##
LabVIEW 2009 Full Development or higher
G# Framework version 1.2.0 or higher
StarUML version 5.0 or higher

## SUPPORTED OPERATING SYSTEMS ##
Windows XP/Vista/7 

## INSTALLATION ##

1. Install the G# Framework, download from www.addq.se
2. Install StarUML (download from http://staruml.sourceforge.net/en/download.php). Make sure you have set decimal point to "." and not ", in your reginal settings in Windows. StarUML require this.
3. Unzip the G#StarUML Plug-in zip-file.
4. Run the G#StarUMLPluginInstaller.vi. Make sure StarUML is not running and that you have administrator rights. In Windows 7 and Vista, you may need to launch LabVIEW.exe as "Run as administrator" (even though you have administrator rights) by right-clicking LabVIEW.exe in the Windows explorer and choose "Run as Administrator".
5. Press the 'Install' button.
6. Restart LabVIEW.
7. Done!

## UNINSTALLATION ##

1. Run the G#StarUMLPluginInstaller.vi in the installation zip-file.
2. Press 'Uninstall' button.
3. Restart LabVIEW.
4. Done!

## EXAMPLES ##
There are a lot of examples of how to use the G# StarUML Plug-in in <LabVIEW>/examples/AddQ/G# UML.
These examples are also searchable in the LabVIEW �Find Examples��. Search for �UML�.

## SUPPORT ##
Help is available in:
<StarUML>\modules\staruml-gsharp\GSharpAddIn.chm (if you have trouble view this file, please right-click on the file in Explorer and select Properties and there is a button called 'Unblock')

or visit the online manual:
http://www.addq.se/document/GsharpUMLOnlineManual.htm

StarUML on Wikipedia
http://en.wikipedia.org/wiki/StarUML

StarUML Official website
http://staruml.sourceforge.net/en/

StarUML Discussion Forum
http://sourceforge.net/projects/staruml/forums/forum/510443/topic/1995257

For support issues, please contact: support@addq.se. Our policy is to respond within one working day. We will not support issues regarding object-oriented design, but we can of course offer this as consultant services. Please contact: sales@addq.se

For information about the latest version and updates, please visit G# StarUML Plug-in website (http://www.addq.se/gsharpuml)

Please join the G# community group for more information, discussions and ideas at:
http://decibel.ni.com/content/groups/gsharp

## LICENSE ##
3-clause license ("New BSD License" or "Modified BSD License")
(http://en.wikipedia.org/wiki/BSD_license#3-clause_license_.28.22New_BSD_License.22_or_.22Modified_BSD_License.22.29)
----------------------------------------------------------------------------------------------------------------------
BSD LICENSE  (http://www.opensource.org/licenses/bsd-license.php).
YOU MAY SUBLICENSE THIS SOFTWARE IN ANY WAY THAT DOES NOT CONFLICT WITH THIS LICENSE.

Copyright (c) 2010, AddQ Consulting <http://www.addq.se>

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

* Neither the name of AddQ nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## RELEASE HISTORY ##

G# StarUML Plug-in 1.2.1

Changed:
* Fixed bug where created classes which had composite aggregations to classes not created caused the code generator to stop. 
* When generating code you only have to apply one class base path for code generation. All other classes will be by default using the first path applied. The option to change path on individual classes are still there.
* When generating classes for the first time the class header and body colors are randomly selected
* Fixed bug where generator stops when user presses "ctrl" and ".".

Known issues:

* Plug-in does not handle class type 'interface' reverse engineering or generation of code
* Generate Code can not reverse shift inheritance
* Generate Code does not update documentation
* Load dialog is shown when generate code or reverse engineering is called from StarUML
* When reverse engineering a project which is unsaved the diagram is not accuratly generated. Save all project and then reverse engineer to solve this.
-------------------------------------

G# StarUML Plug-in 1.2.0

Changed:
* G# StarUML Plug-in is now silver certified!
* Fixed bug where classes which were not to be created had to have a valid file path even though "Create class" checker was unchecked.

-------------------------------------

G# StarUML Plug-in 1.1.0

Changed:
* Adapted to changes in G# Framework 1.2.0
* Generate Code can now add or update LabVIEW native class attributes

-------------------------------------

G# StarUML Plug-in 1.0.2.6

Changed:

* Installer now handles 64 bits systems
* Version info now handles 64 bits systems
* Right click -> Generate code works for selected classes/models
* Right click -> Reverse engineer works for selected classes/models
* Generate code now supports labview native, static and G# class templates

-------------------------------------
G# StarUML Plug-in 1.0.2.5

* Installer checks that StarUML is installed
* Example classes inherits wire appearance of its parents
* Getting started is added to help
* Right click in StarUML can activate code generation and reverse engineering
* Code generation does not show class file extensions
* Code generation pop up now has a working cancel button (!)
* Code generation is prevented from creating G#Object.lvclass and all other G#Ide or G# StarUML Plug-in classes
-------------------------------------
G# StarUML Plug-in 1.0.2.4

* Class is now saved when attributes are changed or added
* Aggregate functions in both generate code and reverse engineering is fully functional.
* Fixed example uml file which was corrupt.

-------------------------------------
G# StarUML Plug-in 1.0.2.3
* Added G# approach for StarUML

-------------------------------------
G# StarUML Plug-in 1.0.2.2

* All attribute datatypes reversed engineered is now of GSharp type and can be generated
* Disabled 'ok' button in class dialog if all class paths isn't applied
* Changed progress bars to system in 'Generate Code' and 'Reverse Engineer"

-------------------------------------
G# StarUML Plug-in 1.0.2.1

* Minor cosmetic changes to dialogs
* Updated Help
* Generate Code is now available!
-------------------------------------
G# StarUML Plug-in 1.0.2.0

* Fixed version information dialog

-------------------------------------
G# StarUML Plug-in 1.0.0.0

* First release

