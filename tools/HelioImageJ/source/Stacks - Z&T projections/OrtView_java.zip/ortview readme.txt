Copyright � by MedNuc, 2002. All rights reserved.
By downloading the software you agree to this copyright notice and disclaimer.

Permission to copy and use the software and accompanying documentation provided on these webpages for educational, research, and not-for-profit purposes, without fee and without a signed licensing agreement, is hereby granted, provided that this copyright notice appears in all copies. The copyright holder is free to make upgraded or improved versions of the software available for a fee or commercially only. Contact the copyright holder for commercial licensing opportunities.

In no event shall the copyright holder be liable to any party for any kind of damages arising out of the use of this software and its documentation. The copyright holder specifically disclaims any warranties. The software and accompanying documentation is provided "as is". The copyright holder has no oblicagion to provide maintenance, support, enhancements or modifications.