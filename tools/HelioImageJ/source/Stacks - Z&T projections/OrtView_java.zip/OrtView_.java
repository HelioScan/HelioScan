/*

 OrtView_.java
 Autumn 2001

 This plugin performs the following:

 - it creates a 3D matrix by interpolating the slices of an active stack

 - it displays the 3D image in an orthogonal system that consists of the three
    views - transaxial, sagittal and coronal

 - it implements some tools that allow some basic interaction






KNOWN BUGS:

NOTES:
- Internally, image values (8 / 16 bit) are casted to int and squeezed within
  the [0,255] range which is the range of values accepted by Jave to display
  images.
  However, in case the input image is of type SHORT, values may originally
  range in the [0,2^16] so that when they are squeezed into the [0,255] interval
  they most probably get changed.
  Hence, when the image is exported back into ImageJ it may have pixel values that look rather different from what they
  originally where...
- Since Interpolation takes up the complete processing power, the interpolation
  module was implemented in a separate thread and a few precaution measures had
  to be taken in order to prevent inconsistencies: no menu item may be called
  while interpolation is being computed. This rude multithreading was
  necessary to have the progressBar correctly displayed.

*/


// Import Java
import java.io.*;
import java.lang.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
//import com.borland.jbcl.layout.*;


// Import ImageJ
import ij.*;
import ij.gui.*;
import ij.process.*;
import ij.measure.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import ij.plugin.filter.PlugInFilter;
import ij.text.*;





// ========================================================================
// -----------------------------------------------------------

// Class OrtViewFrame
// The main class.
// It implements the data structure (a matrix) that represents the
// 3D image it obtains the data from the active imageJ stack


public class OrtView_ implements PlugInFilter, MouseListener, MouseMotionListener, ActionListener
{

   // Global variables

   // variables strictly related to the image
   ImagePlus imgOrig;
   OrtViewFrame imgFrame;
   Point imgFrameLocation;
   int img3D[][][];                         // internal image representation
   int img3DUnrotated[][][];                // backup unrotated img when rotation is called
   int wOrig, hOrig, zOrig;                 // original image dimensions
   int w, h, z, zCorr;                      // image dimensions (may change after a rotation)
   int zCorrUnrotated;                      // backup zCorr before (the first) rotation
   private ColorModel cModel;
   private boolean imgTypeShort;
   private int pixTx[], pixCr[], pixSg[];   // matrix to hold the three image slices
   private int pixVol[];                    // matrix to hold the "Volume view"

   // interpolation
   OrtViewInterpolation interpConsumer;         // inner class
   static boolean finishingInterpFlag = false;  // flag that prevents new crosshair from
												// being set while interpThread is finishing up
   static boolean computingInterpolationFlag = false; // flag to avoid OpenConfig to proceed
												// while interpolation is being computed
   // rotation
   OrtViewRotation rotationConsumer;            // inner class
   static boolean finishingRotationFlag = false;// (see interpolation variables)
   static boolean computingRotationFlag = false;
   private boolean imgRotated = false;
   int img3DRotating[][][];                     // obj to temporarily save img values while performing a rotation
   private int generalFlag = 1;                 // flag used for diverse things (dirty programming!! be careful!!)

   // variables for the user interaction
   int wCurr, hCurr, zCurr;        // CROSSHAIR LOCATION: currently active sections
   int zSpacing = 1;               // INTERPOLATION
   double voxel_xDim, voxel_zDim;  // voxel_yDim is implicitly assumed to be equal to voxel_xDim
   int interpType;                 // 0=linear;             1=Spline;       2=Polynomial
   int measurementUnit = 0;        // 0=pixel;              1=mm
   int vertOrientationChoice = 0;  // ORIENTATION CHOICE: 0=Nuclear Medicine;   1=Radiology
   int rotationSequence = 0;       // ROTATION: 0=xyz 1=xzy 2=yxz 3=yzx 4=zxy 5=zyx
   int rotationAngleW = 0, rotationAngleH = 0, rotationAngleZ = 0;



   // --------------------------------------------------
   // initialize global variables

   public int setup(String arg, ImagePlus imgOrig)
   {
    IJ.write("\n\n========================================\nOrtView Begin\n");
    if (IJ.debugMode)
         IJ.write("DEBUG OrtView > Entering setup()");


    // about
    if (arg.equals ("about"))
    {   if (IJ.debugMode)
	    IJ.write ("DEBUG OrtView > setup() leaving plugin.");
        showAbout();
        return DONE;
    }
    IJ.showStatus("OrtView");


    // retrieve image properties
    this.imgOrig = imgOrig;
    if(imgOrig==null)
    {   IJ.noImage();
        return DONE;
    }
    imgTypeShort = (imgOrig.getType()==ImagePlus.GRAY16) ? true : false;


    // size
    w = wOrig = imgOrig.getWidth();
    h = hOrig = imgOrig.getHeight();
    z = zOrig = imgOrig.getStackSize();
    if (z<2)
    {   IJ.error("Stack required");
        return DONE;
    }
    wCurr = w/2;
    hCurr = h/2;
    zCurr = imgOrig.getCurrentSlice();

    // measurement unit
    String strTmp = imgOrig.getCalibration().getUnits();
    if (strTmp == "mm")
        measurementUnit = 1;
    else measurementUnit = 0; // pixel

    // voxel dimension and...
    voxel_xDim = imgOrig.getCalibration().pixelWidth; // assumed the same as voxel_yDim
    voxel_zDim = imgOrig.getCalibration().pixelDepth; // these values are set to 1 by default by ImageJ if nothing else is specified

    // ...interpolation method to use
    // there are three (axial) interpolation methods: polynomial, cubic spline and linear;
    // at the beginning, i.e. before the user can specify anything, linear interpolation
	// is performed, since it is by far the fastest and the three views are displayed
	// immediately (see run()).
	// However, depending on the pixel values a different interpolation method
	// should be set as default in case the user explicitly starts the interp.process
	// (Menu -> Process -> Interpolate...)
	if (((voxel_zDim != 1.0) && (voxel_xDim != 1.0))   // pixel dimensions are not default ones, but specifically set
		   && (voxel_zDim != 0) && (voxel_xDim != 0))  // neither null
	{   interpType = 1;                                // cubic spline
		// set zSpacing for initial linear interpolation to reflect pixel proportions
		zSpacing = Math.max (1, (int)Math.round((double)voxel_zDim / voxel_xDim));
	}
    else interpType = 0;                               // linear
    // polynomial type can only be activated by the user through Menu Process->Interpolation


    // color map
    cModel = imgOrig.getProcessor().getColorModel();
    if (imgTypeShort)
        IJ.write ("WARNING: Visual artifacts may appear on short images\n         Change Brightness/Contrast to correct them.");



    if (IJ.debugMode)
    {   IJ.write ("DEBUG OrtView > setup() measurement unit: "+strTmp+" (choice "+measurementUnit+")");
       	IJ.write ("DEBUG OrtView > setup() pixel Dimension: retrieved ("+voxel_xDim+","+voxel_zDim+"), assumed ("+voxel_xDim+","+voxel_xDim+","+voxel_zDim+")");
       	IJ.write ("DEBUG OrtView > setup() done.");
    }
    return DOES_8G+DOES_16+STACK_REQUIRED+NO_CHANGES;
 }





    // --------------------------------------------------
    // performs the actual job

  public void run(ImageProcessor ip)
  {
    if (IJ.debugMode)
    {   IJ.write("DEBUG OrtView > Entering run()");
        IJ.write ("Total Memory: "+Runtime.getRuntime().totalMemory());
        IJ.write ("Free Memory:  "+Runtime.getRuntime().freeMemory());
        IJ.write ("Used Memory:  "+(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory()));
    }

	// set up the object for interpolation (this will be used when user calls
	// Menu -> Process -> Interpolation... or Menu -> File -> Open Config)
	// and, similarly, for rotation
    interpConsumer = new OrtViewInterpolation();
	rotationConsumer = new OrtViewRotation();


    // compute the 3D matrix and the three sections
	computeImg3DLinearly();                // linear axial interpolation (interpType==0)
	finishingInterpFlag = false;           // unlock crosshair-moving capability
										   // (see methods mouseReleased() and computeImg3D*())
    Reslice();




    // compute the screen location for the output

    ImageWindow winOrig = imgOrig.getWindow();
    int winOrigTxPos = winOrig.getX();
    int winOrigSgPos = winOrig.getY();
    int winOrigHeight = winOrig.getHeight();
    int winHeight, winVertPos;
    final int yScreenDim = 600;

    if (IJ.debugMode)
        IJ.write("DEBUG OrtView > run(): computing frame location");
    winHeight = (int)((h+zCorr)*1.15);
    if ((winOrigSgPos + winOrigHeight + winHeight) > yScreenDim)
        winVertPos = yScreenDim - 1 - winHeight;
    else
        winVertPos = winOrigSgPos+winOrigHeight;
	if (winVertPos < 0) winVertPos = 1;

	imgFrameLocation = new Point (winOrigTxPos, winVertPos);




    // preparing the output

    if (IJ.debugMode)
        IJ.write("DEBUG OrtView > run(): arranging views in output frame");
    try
    {    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception e)
    {    e.printStackTrace();
    }
    if (IJ.debugMode)
        IJ.write("DEBUG OrtView > run(): w="+w+" h="+h+" zCorr="+zCorr);


	createFrame();



		// finishing up

        IJ.register(OrtView_.class);
        if (IJ.debugMode)
        {   IJ.write ("DEBUG OrtView > run(): register class");
			IJ.write ("DEBUG OrtView > run() done. Begin user interaction...\n\n");
            IJ.write ("Total Memory: "+Runtime.getRuntime().totalMemory());
            IJ.write ("Free Memory:  "+Runtime.getRuntime().freeMemory());
            IJ.write ("Used Memory:  "+(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory()));
        }
    }







   // --------------------------------------------------
   // creates the frame and displays it
   private void createFrame()
   {

    imgFrame = new OrtViewFrame(w, h, zCorr, vertOrientationChoice);

    imgFrame.validate();    // Validate frames that have preset sizes
    imgFrame.pack();        // Pack frames that have useful preferred size info, e.g. from their layout
    imgFrame.setLocation(imgFrameLocation);     // Position the window exactly where it was
    imgFrame.setVisible(true);
    imgFrame.setResizable(false);

//    WindowManager.setCurrentWindow(winOrig); // I assume this is useless...
    if (IJ.debugMode)
        IJ.write("DEBUG OrtView > run(): main frame created; now adding images");



    // create and display the three sections along with the crosshair cursors

    imgFrame.createImages (pixTx, pixCr, pixSg, cModel);
    imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
    imgFrame.showImages ();
    imgFrame.drawCrosshairs();
    // repaints e.th, including the borders...^^-; !!
    imgFrame.paint(imgFrame.getGraphics());




    // add interaction

    // mouse interaction
    imgFrame.panTx.addMouseListener(this);
    imgFrame.panCr.addMouseListener(this);
    imgFrame.panSg.addMouseListener(this);
    imgFrame.panTx.addMouseMotionListener(this);
    imgFrame.panCr.addMouseMotionListener(this);
    imgFrame.panSg.addMouseMotionListener(this);
    // menu interaction
    imgFrame.menuBar.menuItemSave.addActionListener(this);
    imgFrame.menuBar.menuItemOpen.addActionListener(this);
    imgFrame.menuBar.menuItemExpTxImg.addActionListener(this);
    imgFrame.menuBar.menuItemExpCrImg.addActionListener(this);
    imgFrame.menuBar.menuItemExpSgImg.addActionListener(this);
    imgFrame.menuBar.menuItemExp3Img.addActionListener(this);
    imgFrame.menuBar.menuItemExpTxStk.addActionListener(this);
    imgFrame.menuBar.menuItemExpCrStk.addActionListener(this);
    imgFrame.menuBar.menuItemExpSgStk.addActionListener(this);
    imgFrame.menuBar.menuItemExp3Stk.addActionListener(this);
    imgFrame.menuBar.menuItemQuitOrtview.addActionListener(this);
    imgFrame.menuBar.menuItemInterpolate.addActionListener(this);
    imgFrame.menuBar.menuItemSmooth3.addActionListener(this);
    imgFrame.menuBar.menuItemSmooth8.addActionListener(this);
    imgFrame.menuBar.menuItemSmooth27.addActionListener(this);
    imgFrame.menuBar.menuItemRotate.addActionListener(this);
    imgFrame.menuBar.menuItemUndoRotate.addActionListener(this);
    imgFrame.menuBar.menuItemReset.addActionListener(this);
    imgFrame.menuBar.menuItemNuclMed.addActionListener(this);
    imgFrame.menuBar.menuItemRadiology.addActionListener(this);
    imgFrame.menuBar.menuItemVolView.addActionListener(this);
    imgFrame.menuBar.menuItemCrosshair.addActionListener(this);
    imgFrame.menuBar.menuItemAdjustBC.addActionListener(this);


  }




   // --------------------------------------------------
   // this function is called any time values have to be retrieved from the
   // original ImageJ image: it checks that its dimension has not
   // changed in the meanwhile (this may happen if the user for instance
   // delets some planes or crops the image)...
   private boolean checkImgOrig()
   {
        if (wOrig != imgOrig.getWidth())
		   return false;
        if (hOrig != imgOrig.getHeight())
		   return false;
        if (zOrig != imgOrig.getStackSize())
		   return false;
		return true;

   }




   // --------------------------------------------------
   // This function is called if the image type is SHORT:
   // it scales the original image values into [0,255].

   // This is necessary because OrtView displays images using standard Java
   // function calls, that need pixel values to be within the [0,255] interval;
   // hence, short images need to be scaled (their real values range from 0
   // to 65535).
   // Note, that when images are displayed by using ImageJ functions these
   // operations are not necessary bc the pbl is taken care by setMinAndMax
   // and the LUT

   // Note, that when data is exported back to ImageJ (File->Export)
   // the pixel values may be rather different from those of the original input data.

   private void handleShort()

   {    int imgMin, imgMax;      // min and max values of the original image
        imgMin=img3D[0][0][0];  // initial value: anything
        imgMax=imgMin;

        if (IJ.debugMode)
		   IJ.write ("DEBUG OrtView > handleShort()");

        // compute min and max
        for (int iii = 0; iii < w; ++iii)
            for (int jjj = 0; jjj < h; ++jjj)
                for (int qqq = 0; qqq<zCorr; ++qqq)
                {   if (imgMin > img3D[iii][jjj][qqq])
                        imgMin = img3D[iii][jjj][qqq];
                    if (imgMax < img3D[iii][jjj][qqq])
                        imgMax = img3D[iii][jjj][qqq];
                }
        // rescale
        float a=(float)255/(imgMax-imgMin);
        float b=-a*imgMin;
        for (int iii = 0; iii < w; ++iii)
            for (int jjj = 0; jjj < h; ++jjj)
                for (int qqq = 0; qqq<zCorr; ++qqq)
                {   img3D[iii][jjj][qqq] = Math.round(img3D[iii][jjj][qqq] * a + b);
                    if (img3D[iii][jjj][qqq] > 255) img3D[iii][jjj][qqq]=255;
                    if (img3D[iii][jjj][qqq] < 0) img3D[iii][jjj][qqq]=0;
                }

    }




   // --------------------------------------------------
   // linearly interpolate the original stack slides to obtain a new volume
   // This function is also called when user calls Menu : Process -> Interpolate -> Linear

   public void computeImg3DLinearly()
   {

      // define some local variables
      int kkk, iii, jjj, qqq, newZ;
      int currPixVal, nextPixVal;
      int deltaPix;
      ImageProcessor ipCurrSlice, ipNextSlice;
      ImageStack ims = imgOrig.getStack();


      if (IJ.debugMode)
            IJ.write ("DEBUG computeImg3DLinearly() with zSpacing="+zSpacing);

	  if (!checkImgOrig())
	  {  IJ.error ("Original Image has changed! Please reset image in order to proceed.");
		 return;
	  }

      // initialize some stuff related to the resampling
      int zCorrOld = zCorr;  // backup old zCorr to update zCurr below
	  zCorr = (z-1) * zSpacing +1;
	  if (zCorrOld == 0) zCorrOld = z;       // at plugin initialization
      img3D = new int[w][h][zCorr];
      pixTx = new int[w * h];
      pixCr = new int[w * zCorr];
      pixSg = new int[h * zCorr];
      pixVol = new int[(zCorr + w)*(zCorr + h)];  // w*h to hold the tx img, + an offset zCorr for the cr cut at the top & the sg left/right
      if (zCurr == zCorrOld) zCurr = zCorr;       // last plane
	  else
	  {  // in order to update zCurr I must also consider the case in which interpolation
	     // is shrinking the image axially, i.e. zCorrOld > zCorr
		 // first, scale zCurr to the w x h x z image
		 zCurr = (int)Math.ceil((float)zCurr / (zCorrOld-1) * (z-1));
	     zCurr = zCurr*zSpacing-zSpacing+1;            // initial tx image is the same as currently active one
	  }

      // Short images have to be rescaled to [0,255] for (standard Java) visualization;
      // a backup copy is saved to correctly export data back to ImageJ format
      if (imgTypeShort)
              handleShort();



      // resample slice by slice

      if (IJ.debugMode)
         IJ.write ("DEBUG OrtView > computeImg3DLinearly(): resampling slices");



      // dummy case: zSpacing == 1
      // just copy each slice into the 3D array
      // This block avoids useless interpolation computation
      if (zSpacing == 1)
	  { synchronized (interpConsumer){

	    // see comments at mouseReleased(...) method.
	    finishingInterpFlag = true;

	    for (kkk = 1; kkk <= z; kkk++) // slice counter starts from 1
        {    ipCurrSlice = ims.getProcessor(kkk);
             if (vertOrientationChoice == 1) // Radiology
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                        img3D[iii][jjj][z-kkk] = (int)(ipCurrSlice.getPixel(iii, jjj));
             else                            // Nuclear Medicine
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                            img3D[iii][jjj][kkk-1] = (int)(ipCurrSlice.getPixel(iii, jjj));
         } // kkk
		if (imgFrame != null)                // not at plugin startup
		   if (imgFrame.isDisplayable())     // just in case user killed OrtView window
		   {   imgFrameLocation = imgFrame.getLocation();
			   imgFrame.dispose();
			}
		 IJ.showStatus("OrtView");
		 } // synchronized
         return;
      } // if




	  synchronized (interpConsumer){

	  // see comments at mouseReleased(...) method.
	  finishingInterpFlag = true;

      IJ.showStatus("Resampling image axially by linear interpolation");
      for (kkk = 1; kkk < z; ++kkk)     // Slice counter starts from 1
      {
            ipCurrSlice = ims.getProcessor(kkk);
            ipNextSlice = ims.getProcessor(kkk+1);

	        // assuming that z=nr_of_slices and zSpacing=nr_of_levels (thickness)
            // of each slice, then newZ indexes the first level of the kkk-th slice
            // (in each slice, level counter also starts from 1)
            newZ = (kkk*zSpacing)-zSpacing+1;

            if (vertOrientationChoice == 1) // Radiology
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                    {   currPixVal = ipCurrSlice.getPixel(iii, jjj);
                        nextPixVal = ipNextSlice.getPixel(iii, jjj);
                        deltaPix = (nextPixVal - currPixVal) / zSpacing;
                        for (qqq = newZ; qqq < newZ+zSpacing ; ++qqq)
                            img3D[iii][jjj][zCorr-qqq] = (int)(currPixVal + deltaPix*(qqq-newZ));
                    }
            else                            // Nuclear Medicine
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                    {   currPixVal = ipCurrSlice.getPixel(iii, jjj);
                        nextPixVal = ipNextSlice.getPixel(iii, jjj);
                        deltaPix = (nextPixVal - currPixVal) / zSpacing;
                        for (qqq = newZ; qqq < newZ+zSpacing ; ++qqq)
                            img3D[iii][jjj][qqq-1] = (int)(currPixVal + deltaPix*(qqq-newZ));
                    }
        } // for kkk



        // copy last slice
        ipCurrSlice = ims.getProcessor(z);
        if (vertOrientationChoice == 1) // Radiology
            for (iii = 0; iii < w; ++iii)
                for (jjj = 0; jjj < h; ++jjj)
                    img3D[iii][jjj][0] = (int)ipCurrSlice.getPixel(iii, jjj);
        else                            // Nuclear Medicine
            for (iii = 0; iii < w; ++iii)
                for (jjj = 0; jjj < h; ++jjj)
                    img3D[iii][jjj][zCorr-1] = (int)ipCurrSlice.getPixel(iii, jjj);



		if (imgFrame != null)                // not at plugin startup
		   if (imgFrame.isDisplayable())     // just in case user killed OrtView window
		   {   imgFrameLocation = imgFrame.getLocation();
			   imgFrame.dispose();
			}
        IJ.showStatus("OrtView");
		}  // synchronized
		return;
   }





   // --------------------------------------------------
   // interpolate the slides of the stack to obtain a new volume, using cubic splines
   // This function is based on the polinomial interpolation routine of
   // "Numerical Recipes in [C]", 2nd edition, pp.115
   // This function is also called when user calls Menu : Process -> Interpolate -> Spline

   public boolean computeImg3DSpline()
    {
      // define some local variables
      int kkk, iii, jjj;
      int y[];
	  float y2[];
      ImageStack ims = imgOrig.getStack();
      ProgressMonitor prgrMonitor = new ProgressMonitor(imgFrame, "Cubic Spline axial interpolation", "", 0,w-1);

      // - to compute the nr of slices, take into account the relation voxel_zDim/voxel_xDim
      // in order to preserve "visualization consistency"
      // - also, we want the first and the last "original" planes to keep being the
      // "boundary planes" in the new,interpolated volume, hence "(z-1) + 1" rather than "z"
      // - finally, (int)cast truncates, hence "+0.5" in order to round
      int zCorrLocal = (int)(voxel_zDim/voxel_xDim * (z-1) + 1.5);
      int [][][] img3DLocal = new int[w][h][zCorrLocal];




      if (IJ.debugMode)
            IJ.write ("DEBUG OrtView > computeImg3DSpline() with voxel_zDim="+voxel_zDim);
	  if (!checkImgOrig())
	  {  IJ.error ("Original Image has changed! Please reset image in order to proceed.");
		 return false;
	  }




      // dummy case: voxel_xDim == voxel_zDim
      // just copy each slice into the 3D array
      // This block avoids useless interpolation computation
      if (voxel_xDim == voxel_zDim)
      { for (kkk = 1; kkk <= z; kkk++) // slice counter starts from 1
        {   ImageProcessor ipCurrSlice = ims.getProcessor(kkk);
            if (vertOrientationChoice == 1) // Radiology
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                        img3DLocal[iii][jjj][z-kkk] = (int)(ipCurrSlice.getPixel(iii, jjj));
            else                            // Nuclear Medicine
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                        img3DLocal[iii][jjj][kkk-1] = (int)(ipCurrSlice.getPixel(iii, jjj));
         } // kkk
      }








	  else {        // complex case: computation may take several minutes

      // resample each single axial segment

      if (IJ.debugMode)
         IJ.write ("DEBUG OrtView > computeImg3DSpline(): resampling axial segments");

      IJ.showStatus("Resampling image axially (by cubic spline interpolation)");
      y = new int [z];
	  y2 = new float [z];


      // (note: I know that the code would look smarter by putting the
      // following if condition inside each single loop, but the following way
      // should be more efficient in that it avoids 'zCorrLocal' if-conditions...)
      if (vertOrientationChoice == 1) // Radiology
      { for (iii = 0; iii < w; ++iii)
        {   IJ.showProgress ((double)iii/w);
			IJ.showStatus((Math.round(((float)iii/w)*100.0))+"%");
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
			prgrMonitor.setProgress(iii);
            prgrMonitor.setNote((Math.round(((float)iii/w)*100.0))+"%");
            for (jjj = 0; jjj < h; ++jjj)
            {
                // extract axial segment from the original 3D image
                for (kkk = 0; kkk < z; kkk++)
                y[kkk] = ims.getProcessor(kkk+1).getPixel(iii,jjj);

                // force boundary elements of the segment to remain unchanged in the interpolated result...
                img3DLocal[iii][jjj][zCorrLocal-1] = y[0];
                img3DLocal[iii][jjj][0] = y[z-1];

		        // initialize spline computation (compute second derivative)
		        computeSpline(y, y2);

                // compute interpolation over the internal elements of the segment
                for (kkk = 1; kkk < zCorrLocal-1; kkk++)
                {   float x = (float)(z-1)/(zCorrLocal-1) * (float)kkk;
                    int valores = computeSplineInterp(y, y2, x);
                    if (valores<0) valores=0;
                    img3DLocal[iii][jjj][zCorrLocal-kkk-1] = valores;
                }
            } // jjj
        } // iii
      } // if verticalOrientationChoice
      else                            // Nuclear Medicine
      {
        for (iii = 0; iii < w; ++iii)
        {   IJ.showProgress ((double)iii/w);
			IJ.showStatus((Math.round(((float)iii/w)*100.0))+"%");
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
			prgrMonitor.setProgress(iii);
            prgrMonitor.setNote((Math.round(((float)iii/w)*100.0))+"%");
            for (jjj = 0; jjj < h; ++jjj)
            {
                // extract axial segment from the original 3D image
                for (kkk = 0; kkk < z; kkk++)
                y[kkk] = ims.getProcessor(kkk+1).getPixel(iii,jjj);

                // force boundary elements of the segment to remain unchanged in the interpolated result...
                img3DLocal[iii][jjj][0] = y[0];
                img3DLocal[iii][jjj][zCorrLocal-1] = y[z-1];

		        // initialize spline computation (compute second derivative)
		        computeSpline(y, y2);

                // compute interpolation over the internal elements of the segment
                for (kkk = 1; kkk < zCorrLocal-1; kkk++)
                {   float x = (float)(z-1)/(zCorrLocal-1) * (float)kkk;
                    int valores = computeSplineInterp(y, y2, x);
                    if (valores<0) valores=0;
                    img3DLocal[iii][jjj][kkk] = valores;
                }
            } // jjj
        } // iii
     } // if-else verticalOrientationChoice



     prgrMonitor.close();



	 } // end of "complex case" (long computation)


synchronized (interpConsumer){

	// see comments at mouseReleased(...) method.
	finishingInterpFlag = true;

	// kill currently active OrtView window saving its location first
	if (imgFrame != null)                // not at plugin startup
	   if (imgFrame.isDisplayable())     // just in case user killed OrtView window
	   {   imgFrameLocation = imgFrame.getLocation();
		   imgFrame.dispose();
		}

	 // at this point user cannot cancel operation any more;
	 // the time is safe to update all values
	 int zCorrOld = zCorr; // backup zCorr to update zCurr below
	 zCorr = zCorrLocal;
	 if (zCorrOld == 0) zCorrOld = z;       // at plugin initialization
	 img3D = img3DLocal;
     // Short images have to be rescaled to [0,255] for (standard Java) visualization;
     if (imgTypeShort)
		  handleShort();

	  // these variables need to be updated here for future use, since their dimension has now changed...
	  pixTx = new int[w * h];
      pixCr = new int[w * zCorr];
      pixSg = new int[h * zCorr];
      pixVol = new int[(zCorr + w)*(zCorr + h)];  // w*h to hold the tx img, + an offset zCorr for the cr cut at the top & the sg left/right
      if (zCurr == zCorrOld) zCurr = zCorr;       // last plane
	  else
	  {  // in order to update zCurr I must also consider the case in which interpolation
	     // is shrinking the image axially, i.e. zCorrOld > zCorr
		 // first, scale zCurr to the w x h x z image
		 zCurr = (int)Math.ceil((float)zCurr / (zCorrOld-1) * (z-1));
	     zCurr = (int)((zCurr-1)*(zCorr-1)/(z-1) +1.5);   // initial tx image is the same as currently active one
	  }


     IJ.showProgress(100);
     IJ.showStatus("OrtView");
} // synchronized
	 return true;

   }








   // --------------------------------------------------
   // Processes an entire tabulated function; This function is
   // called only once on each tabulated data set.

   private void computeSpline(int y[], float y2[])
   {  // y is the vector of points that are interpolated (i.e. the axial segment of the 3D image)
	  // y2 is a vector returned by the function, containing the second derivatives
	  // of the interpolating function at the tabulated points
      // what in Numerical Recipes is refered to as "x" is here simply the vector
      //      of indices [1,...,z]

	  // boundary conditions for a natural splines are assumed, namely,
	  // zero second derivative on the boundary itself


	  // initialize stuff...
	  float u[];
      u = new float[z-1];
	  y2[z-1] = 0;    // Upper and...
	  y2[0] = 0;      // Lower boudary conditions are set to be "natural"
	  u[0] = 0;


	  // Decomposition loop of the tridiagonal algorithm
	  // y2 and u are used for temp storage of the decomposed factors
	  for (int i=1; i<z-1; i++)
	  {     float p = y2[i-1] / 2 + 2;
		    y2[i] = -(float)0.5/p;
    		u[i] = y[i+1] - 2*y[i] + y[i-1];
	    	u[i] = (3*u[i] - u[i-1]/2)/p;
	  }

	  // Backsubstitution loop of the tridiagonal algorithm
	  for (int k=z-2; k>=0; k--)
	      y2[k]=y2[k]*y2[k+1]+u[k];


   }




   // --------------------------------------------------
   // Computes the values of the interpolated function for any value of x

    private int computeSplineInterp(int ya[], float y2a[], float x)
    {   // ya is the vector of points that are interpolated (i.e. the axial segment of the 3D image)
        // y2a is the output from computeSpline() and it contains the second derivative of
        // the tabulated function
        // x is the point for which the value y is computed and returned by the function
        // what in Numerical Recipes is refered to as "xa" is simply the vector
        //      of indices [1,...,z] here

        float a, b;

        int klo, khi;       // klo (k low) and khi (k high) bracket the input value of x
        if ((int)x==z)
        {   klo = (int) (x-1);
            khi = z;
        }
        else
        {   klo = (int) x;
            khi = (int) (x+1);
        }
        a = khi - x;
        b = x - klo;
        // evaluation of the cubic spline polynomial:
        return ((int) (a*ya[klo] + b*ya[khi] + ((a*a*a-a)*y2a[klo] + (b*b*b-b)*y2a[khi]) /6 + (float)0.5));

    }





   // --------------------------------------------------
   // polinomially interpolate the original stack slides to obtain a new volume
   // This function is based on the polinomial interpolation routine of
   // "Numerical Recipes in [C]", 2nd edition, pp.108
   // This function is also called when user calls Menu : Process -> Interpolate -> Polynomially

   public boolean computeImg3DPolyn()
   {
      // define some local variables
      int kkk, iii, jjj;
      int y[];
      ImageStack ims = imgOrig.getStack();
      ProgressMonitor prgrMonitor = new ProgressMonitor(imgFrame, "Polynomial axial interpolation", "", 0,w-1);

      // - to compute the nr of slices, take into account the relation voxel_zDim/voxel_xDim
      // in order to preserve "visualization consistency"
      // - also, we want the first and the last "original" planes to keep being the
      // "boundary planes" in the new,interpolated volume, hence "(z-1) + 1" rather than "z"
      // - finally, (int)cast truncates, hence "+0.5" in order to round
      int zCorrLocal = (int)(voxel_zDim/voxel_xDim * (z-1) + 1.5);
      int [][][] img3DLocal = new int[w][h][zCorrLocal];


	  if (!checkImgOrig())
	  {  IJ.error ("Original Image has changed! Please reset image in order to proceed.");
		 return false;
	  }


      if (IJ.debugMode)
            IJ.write ("DEBUG OrtView > computeImg3DPolyn() with voxel_zDim="+voxel_zDim);


      // dummy case: voxel_xDim == voxel_zDim
      // just copy each slice into the 3D array
      // This block avoids useless interpolation computation
      if (voxel_xDim == voxel_zDim)
        for (kkk = 1; kkk <= z; kkk++) // slice counter starts from 1
        {   ImageProcessor ipCurrSlice = ims.getProcessor(kkk);
            if (vertOrientationChoice == 1) // Radiology
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                        img3DLocal[iii][jjj][z-kkk] = (int)(ipCurrSlice.getPixel(iii, jjj));
            else                            // Nuclear Medicine
                for (iii = 0; iii < w; ++iii)
                    for (jjj = 0; jjj < h; ++jjj)
                        img3DLocal[iii][jjj][kkk-1] = (int)(ipCurrSlice.getPixel(iii, jjj));
        } // kkk






	  else {        // complex case: computation may take several minutes

      // resample each single axial segment

      if (IJ.debugMode)
         IJ.write ("DEBUG OrtView > computeImg3DPolyn(): resampling axial segments");

      IJ.showStatus("Resampling image axially (by polynomial interpolation)");
      y = new int [z];


      // (note: I know that the code would look smarter by putting the
      // following if condition inside each single loop, but the following way
      // should be more efficient in that it avoids 'zCorrLocal' if-conditions...)
      if (vertOrientationChoice == 1) // Radiology
        for (iii = 0; iii < w; ++iii)
        {   IJ.showProgress ((double)iii/w);
			IJ.showStatus((Math.round(((float)iii/w)*100.0))+"%");
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
            prgrMonitor.setProgress(iii);
            prgrMonitor.setNote((Math.round(((float)iii/w)*100.0))+"%");
            for (jjj = 0; jjj < h; ++jjj)
            {
                // extract axial segment from the original 3D image
                for (kkk = 0; kkk < z; kkk++)
                y[kkk] = ims.getProcessor(kkk+1).getPixel(iii,jjj);

                // force boundary elements of the segment to remain unchanged in the interpolated result...
                img3DLocal[iii][jjj][zCorrLocal-1] = y[0];
                img3DLocal[iii][jjj][0] = y[z-1];

                // compute interpolation over the internal elements of the segment
                for (kkk = 1; kkk < zCorrLocal-1; kkk++)
                {   float x = (float)(z-1)/(zCorrLocal-1) * (float)kkk;
                    int valores = computePolynInterp(y, x);
                    if (valores < 0) valores=0;
                    img3DLocal[iii][jjj][zCorrLocal-kkk-1] = valores;
                }
            } // jjj
        } // iii
      else                            // Nuclear Medicine
        for (iii = 0; iii < w; ++iii)
        {   IJ.showProgress ((double)iii/w);
			IJ.showStatus((Math.round(((float)iii/w)*100.0))+"%");
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
            prgrMonitor.setProgress(iii);
            prgrMonitor.setNote((Math.round(((float)iii/w)*100.0))+"%");
            for (jjj = 0; jjj < h; ++jjj)
            {
                // extract axial segment from the original 3D image
                for (kkk = 0; kkk < z; kkk++)
                y[kkk] = ims.getProcessor(kkk+1).getPixel(iii,jjj);

                // force boundary elements of the segment to remain unchanged in the interpolated result...
                img3DLocal[iii][jjj][0] = y[0];
                img3DLocal[iii][jjj][zCorrLocal-1] = y[z-1];

                // compute interpolation over the internal elements of the segment
                for (kkk = 1; kkk < zCorrLocal-1; kkk++)
                {   float x = (float)(z-1)/(zCorrLocal-1) * (float)kkk;
                    int valores = computePolynInterp(y, x);
                    if (valores < 0) valores=0;
                    img3DLocal[iii][jjj][kkk] = valores;
                }
            } // jjj
        } // iii
     prgrMonitor.close();



	 } // end of "complex case" (long computation)


synchronized (interpConsumer){

	 // see comments at mouseReleased(...) method.
	 finishingInterpFlag = true;


	 // kill currently active OrtView window, saving its location first
	 if (imgFrame != null)                // not at plugin startup
		if (imgFrame.isDisplayable())     // just in case user killed OrtView window
		{   imgFrameLocation = imgFrame.getLocation();
			imgFrame.dispose();
		}

	 // at this point user cannot cancel operation any more;
	 // the time is safe to update all values

	 int zCorrOld = zCorr;  // this will be used below to update zCurr
	 zCorr = zCorrLocal;
	 if (zCorrOld == 0) zCorrOld = z;       // at plugin initialization
	 img3D = img3DLocal;
     // Short images have to be rescaled to [0,255] for (standard Java) visualization
     if (imgTypeShort)
		  handleShort();

	  // these variables need to be updated here for future use, since their dimension has now changed...
	  pixTx = new int[w * h];
      pixCr = new int[w * zCorr];
      pixSg = new int[h * zCorr];
      pixVol = new int[(zCorr + w)*(zCorr + h)];  // w*h to hold the tx img, + an offset zCorr for the cr cut at the top & the sg left/right
      if (zCurr == zCorrOld) zCurr = zCorr;       // last plane
	  else
	  {  // in order to update zCurr I must also consider the case in which interpolation
	     // is shrinking the image axially, i.e. zCorrOld > zCorr
		 // first, scale zCurr to the w x h x z image
		 zCurr = (int)Math.ceil((float)zCurr / (zCorrOld-1) * (z-1));
	     zCurr = (int)((zCurr-1)*(zCorr-1)/(z-1) +1.5);   // initial tx image is the same as currently active one
	  }



     IJ.showProgress(100);
     IJ.showStatus("OrtView");
	 } // synchronized
	 return true;
   }






   // --------------------------------------------------
   // Computes the value y of the interpolating polynomial at location x;
   // the polynomial has degree z-1 (i.e. it passes through z points (i,ya[i])
   // for i = 0,...,z-1 )

   private int computePolynInterp(int ya[], float x)
   {    // ya is the vector of points that are interpolated (i.e. the axial segment of the 3D image)
        // x is the point for which the value P(x) is computed;
        // this is the value that is returned by the function
        // what in Numerical Recipes is refered to as "xa" is simply the vector
        //      of indices [1,...,z] here

        // in other words:
        // Given arrays [0,...,z-1] and ya[0,...,z-1], and a value x,
        // then P(x) is the polynomial of degree z-1 such that P(i)=ya[i], with
        // i = 0,...z-1; this routine computes and returns P(x)


        // variables
        float c[], d[];     // vectors with differences
        float yy;           // result
        float den;
        int ns = (int) (x+0.5); // closest index to x
                            // float-to-int cast truncates the float (does not round it!)


        // initialize the c's and d's, i.e. the vectors that keep track of the
        // differences btw parent and daughter polynomials
        c = new float[z];
        d = new float[z];
        for (int i=0; i<z; i++)
        {   c[i] = ya[i];
            d[i] = ya[i];
        }

        // initial approximation to y
        yy = ya[ns--];

        for (int m=1; m<z; m++)           // for each column of the tableau
        {
           for (int i=0; i<z-m; i++)     // loop over c's and d's and update them
            {   den = (d[i]-c[i+1])/m;
                c[i]=(i-x)*den;
                d[i]=(i+m-x)*den;
            } // i
            /* After each column in the tableau is completed, we decide which
            correction, c or d, we want to add to our accumulating value of y,
            i.e., which path to take through the tableau--forking up or down.
            We do this in such a way as to take the most "straight line" route
            through the tableau to its apex, updating ns accordingly to keep track
            of where we are. This route keeps the partial approximations centered
            (insofar as possible) on the target x. The last dy added is thus the
            error indication. */
            yy += (2*ns < z-m) ? c[ns+1] : d[ns--];
        } // for m
        return ((int) (yy+0.5)); // float 2 int cast truncates the float to (no rounding!)
   }






   // --------------------------------------------------
   // rotate the 3D volume by performing three 2D rotation in a row.
   // This method is called from within rotationThread, hence it takes care
   // of setting all flags appropriately, to guarantee mutual exclusion with
   // other "dangerous" pieces of code (e.g. mousePressed(), mouseReleased()).
   // The method rotates the unrotated volume, i.e. if rotation is invoked twice
   // in a row, the operations are not concatenated, but they are applied to the
   // same, unrotated volume.



   public boolean rotate3D()
   {
      int dimLocal[] = new int[3]; // dimensions of the volume - for local use
      if (IJ.debugMode)
            IJ.write ("DEBUG OrtView > rotate3D by x="+rotationAngleW+", y="+rotationAngleH+", z="+rotationAngleZ);
      IJ.showStatus("Rotating volume...");

      if (!imgRotated)              // if no rotation ever before, save ref to unrotated img
	  {	 img3DUnrotated = img3D;
		 zCorrUnrotated = zCorr;    // [w|h]Unrotated = [w|h]Orig anyway....
	  }





      // if at least one angle is different from zero
	  if (rotationAngleW + rotationAngleH + rotationAngleZ > 0)
	  {


	  // initialize rotation object and parameters:
	  // copy the unrotated volume into the local object, adding external
	  // planes as a border that delimits the original, unrotated volume
	  dimLocal[0] = wOrig+2;
	  dimLocal[1] = hOrig+2;
	  dimLocal[2] = zCorrUnrotated+2;
	  img3DRotating = new int [wOrig+2][hOrig+2][zCorrUnrotated+2];
	  // copy volume
	  for (int www=1; www<wOrig+1; www++)
		  for (int hhh=1; hhh<hOrig+1; hhh++)
			  for (int zzz=1; zzz<zCorrUnrotated+1; zzz++)
				  img3DRotating[www][hhh][zzz] = img3DUnrotated[www-1][hhh-1][zzz-1];
	  // add borders
	  for (int www=0; www<wOrig+2; www++)
	  {	  for (int hhh=0; hhh<hOrig+2; hhh++)
			  img3DRotating[www][hhh][0] = img3DRotating[www][hhh][zCorrUnrotated+1] = 254;
		  for (int zzz=0; zzz<zCorrUnrotated+2; zzz++)
			  img3DRotating[www][0][zzz] = img3DRotating[www][hOrig+1][zzz] = 254;
	  }
	  for (int hhh=0; hhh<hOrig+2; hhh++)
		  for (int zzz=0; zzz<zCorrUnrotated+2; zzz++)
			  img3DRotating[0][hhh][zzz] = img3DRotating[wOrig+1][hhh][zzz] = 254;



	  // call 2D rotations in sequence
	  switch (rotationSequence)
	  {  case 0:     // xyz
		     if  (rotationAngleW != 0)
				 if (!rotateW(dimLocal))
					return false;
		     if  (rotationAngleH != 0)
				 if (!rotateH(dimLocal))
					return false;
		     if  (rotationAngleZ != 0)
				 if (!rotateZ(dimLocal))
					return false;
			break;
	    case 1:     // xzy
		     if  (rotationAngleW != 0)
				 if (!rotateW(dimLocal))
					return false;
		     if  (rotationAngleZ != 0)
				 if (!rotateZ(dimLocal))
					return false;
		     if  (rotationAngleH != 0)
				 if (!rotateH(dimLocal))
					return false;
			break;
	    case 2:     // yxz
		     if  (rotationAngleH != 0)
				 if (!rotateH(dimLocal))
					return false;
		     if  (rotationAngleW != 0)
				 if (!rotateW(dimLocal))
					return false;
		     if  (rotationAngleZ != 0)
				 if (!rotateZ(dimLocal))
					return false;
			break;
	    case 3:     // yzx
		     if  (rotationAngleH != 0)
				 if (!rotateH(dimLocal))
					return false;
		     if  (rotationAngleZ != 0)
				 if (!rotateZ(dimLocal))
					return false;
		     if  (rotationAngleW != 0)
				 if (!rotateW(dimLocal))
					return false;
			break;
	    case 4:     // zxy
		     if  (rotationAngleZ != 0)
				 if (!rotateZ(dimLocal))
					return false;
		     if  (rotationAngleW != 0)
				 if (!rotateW(dimLocal))
					return false;
		     if  (rotationAngleH != 0)
				 if (!rotateH(dimLocal))
					return false;
			break;
	    case 5:     // zyx
		     if  (rotationAngleZ != 0)
				 if (!rotateZ(dimLocal))
					return false;
		     if  (rotationAngleH != 0)
				 if (!rotateH(dimLocal))
					return false;
		     if  (rotationAngleW != 0)
				 if (!rotateW(dimLocal))
					return false;
			break;
		default:
			IJ.error ("Internal error on rotation sequence");
			return false;
	  } // switch





	  } // end if at least one angle != 0






	  else // if all angles are zero
	  {  img3DRotating = img3DUnrotated;  // retrieve unrotated volume
	     dimLocal[0] = wOrig;
		 dimLocal[1] = hOrig;
		 dimLocal[2] = zCorrUnrotated;
	  }






synchronized (rotationConsumer){

	 // see comments at mouseReleased(...) method.
	 finishingRotationFlag = true;


	 // kill currently active OrtView window, saving its location first
	 if (imgFrame != null)                // not at plugin startup
		if (imgFrame.isDisplayable())     // just in case user killed OrtView window
		{   imgFrameLocation = imgFrame.getLocation();
			imgFrame.dispose();
		}

	  // at this point user cannot cancel operation any more;
	  // the time is safe to update all values
	  w = dimLocal[0];
	  h = dimLocal[1];
	  zCorr = dimLocal[2];
	  img3D = img3DRotating;
	  img3DRotating = null;
      // if at least one angle is different from zero
	  if (rotationAngleW + rotationAngleH + rotationAngleZ > 0)
	  	  imgRotated = true;
	  else           // release memory that is being hold for nothing...
	  {   imgRotated = false;
		  img3DUnrotated = null;
	  }
	  //imgFrame.menuBar.menuItemUndoRotate.setEnabled(imgRotated);//imgFrame is disposed here...

	  // these variables need to be updated here for future use, since their dimension has now changed...
	  pixTx = new int[w * h];
      pixCr = new int[w * zCorr];
      pixSg = new int[h * zCorr];
      pixVol = new int[(zCorr + w)*(zCorr + h)];  // w*h to hold the tx img, + an offset zCorr for the cr cut at the top & the sg left/right

	  // update crosshair location (center crosshair)
	  wCurr = w/2;
	  hCurr = h/2;
	  zCurr = zCorr/2;

      IJ.showStatus("OrtView");
	  } // synchronized
	  return true;
   }






   // --------------------------------------------------
   // rotation around x-axis
   private boolean rotateW (int dimLocal[])
   {
	    // before rotation
		int imageWidth = dimLocal[1];
		int imageHeight = dimLocal[2];
		double imageWidth2 = imageWidth/2.0;
		double imageHeight2 = imageHeight/2.0;
        int fromX, fromY;
        int shiftX,   shiftY; // offset to rotate around center of img
		// after rotation
        double radians = Math.PI*(rotationAngleW/180.0);                    // first use...
        dimLocal[1] = (int)(Math.abs(imageWidth*Math.cos(radians))+Math.abs(imageHeight*Math.sin(radians))+1);
        dimLocal[2] = (int)(Math.abs(imageWidth*Math.sin(radians))+Math.abs(imageHeight*Math.cos(radians))+1);
		int img3Dtmp[][][] = new int[dimLocal[0]][dimLocal[1]][dimLocal[2]];
		radians  = (((-(rotationAngleW -180) ) %360) / 180.0) * Math.PI;    // second use...
        double cosAngle = Math.cos(radians);
        double sinAngle = Math.sin(radians);


	    ProgressMonitor prgrMonitor = new ProgressMonitor(imgFrame, "Rotation around x axis", "", 0,imageHeight);
		if (IJ.debugMode)
		{   IJ.write ("DEBUG OrtView > rotate by "+radians+" rad around x axis");
			IJ.write("DEBUG OrtView > change volume dimensions ("+(dimLocal[0]-2)+","+(imageWidth-2)+","+(imageHeight-2)+") -> ("+(dimLocal[0]-2)+","+(dimLocal[1]-2)+","+(dimLocal[2]-2)+")");
		}
        for (int y = 0; y < dimLocal[2]; y++)
		{
			// progressMonitor
			IJ.showProgress ((double)y/dimLocal[2]);
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
            prgrMonitor.setProgress(y);
            prgrMonitor.setNote((Math.round(((float)y/imageHeight)*100.0))+"%");

	        shiftY   = (int)(dimLocal[2]/2.0) - y;

			for (int x = 0; x < dimLocal[1]; x++)
	        {   // Rotate around the center of the image.
				shiftX   = (int)(dimLocal[1]/2.0) - x;
                fromX = (int)( ( shiftX * cosAngle) - ( shiftY * sinAngle) + imageWidth2);
                fromY = (int)( ( shiftX * sinAngle) + ( shiftY * cosAngle) + imageHeight2);

                if ( (fromX > -1) && (fromX < imageWidth)  && (fromY > -1) && (fromY < imageHeight) )
				   for (int www = 0; www < dimLocal[0]; www++)
					   img3Dtmp[www][x][y] = img3DRotating[www][fromX][fromY];
            } // End x loop.
        } // End y loop.



     prgrMonitor.close();
     IJ.showProgress(100);
	 img3DRotating = img3Dtmp;
	 img3Dtmp = null;
	 return true;
	}




   // --------------------------------------------------
   // rotation around y-axis
   private boolean rotateH (int dimLocal[])
   {
	    // before rotation
		int imageWidth = dimLocal[0];
		int imageHeight = dimLocal[2];
		double imageWidth2 = imageWidth/2.0;
		double imageHeight2 = imageHeight/2.0;
        int fromX, fromY;
        int shiftX,   shiftY; // offset to rotate around center of img
		// after rotation
        double radians = Math.PI*(rotationAngleH/180.0);                    // first use...
        dimLocal[0] = (int)(Math.abs(imageWidth*Math.cos(radians))+Math.abs(imageHeight*Math.sin(radians))+1);
        dimLocal[2] = (int)(Math.abs(imageWidth*Math.sin(radians))+Math.abs(imageHeight*Math.cos(radians))+1);
		int img3Dtmp[][][] = new int[dimLocal[0]][dimLocal[1]][dimLocal[2]];
		radians  = (((-(rotationAngleH -180) ) %360) / 180.0) * Math.PI;    // second use...
        double cosAngle = Math.cos(radians);
        double sinAngle = Math.sin(radians);


	    ProgressMonitor prgrMonitor = new ProgressMonitor(imgFrame, "Rotation around y axis", "", 0,imageHeight);
		if (IJ.debugMode)
		{   IJ.write ("DEBUG OrtView > rotate by "+radians+" rad around y axis");
			IJ.write("DEBUG OrtView > change volume dimensions ("+(imageWidth-2)+","+(dimLocal[1]-2)+","+(imageHeight-2)+") -> ("+(dimLocal[0]-2)+","+(dimLocal[1]-2)+","+(dimLocal[2]-2)+")");
		}
        for (int y = 0; y < dimLocal[2]; y++)
		{
			// progressMonitor
			IJ.showProgress ((double)y/dimLocal[2]);
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
            prgrMonitor.setProgress(y);
            prgrMonitor.setNote((Math.round(((float)y/imageHeight)*100.0))+"%");

	        shiftY   = (int)(dimLocal[2]/2.0) - y;

			for (int x = 0; x < dimLocal[0]; x++)
	        {   // Rotate around the center of the image.
				shiftX   = (int)(dimLocal[0]/2.0) - x;
                fromX = (int)( ( shiftX * cosAngle) - ( shiftY * sinAngle) + imageWidth2);
                fromY = (int)( ( shiftX * sinAngle) + ( shiftY * cosAngle) + imageHeight2);

                if ( (fromX > -1) && (fromX < imageWidth)  && (fromY > -1) && (fromY < imageHeight) )
				   for (int hhh = 0; hhh < dimLocal[1]; hhh++)
					   img3Dtmp[x][hhh][y] = img3DRotating[fromX][hhh][fromY];
            } // End x loop.
        } // End y loop.



     prgrMonitor.close();
     IJ.showProgress(100);
	 img3DRotating = img3Dtmp;
	 img3Dtmp = null;
	 return true;
   }


   // --------------------------------------------------
   // rotation around z-axis
   private boolean rotateZ (int dimLocal[])
   {
	    // before rotation
		int imageWidth = dimLocal[0];
		int imageHeight = dimLocal[1];
		double imageWidth2 = imageWidth/2.0;
		double imageHeight2 = imageHeight/2.0;
        int fromX, fromY;
        int shiftX,   shiftY; // offset to rotate around center of img
		// after rotation
        double radians = Math.PI*(rotationAngleZ/180.0);                    // first use...
        dimLocal[0] = (int)(Math.abs(imageWidth*Math.cos(radians))+Math.abs(imageHeight*Math.sin(radians))+1);
        dimLocal[1] = (int)(Math.abs(imageWidth*Math.sin(radians))+Math.abs(imageHeight*Math.cos(radians))+1);
		int img3Dtmp[][][] = new int[dimLocal[0]][dimLocal[1]][dimLocal[2]];
		radians  = (((-(rotationAngleZ -180) ) %360) / 180.0) * Math.PI;    // second use...
        double cosAngle = Math.cos(radians);
        double sinAngle = Math.sin(radians);


	    ProgressMonitor prgrMonitor = new ProgressMonitor(imgFrame, "Rotation around z axis", "", 0,imageHeight);
		if (IJ.debugMode)
		{   IJ.write ("DEBUG OrtView > rotate by "+radians+" rad around z axis");
			IJ.write("DEBUG OrtView > change volume dimensions ("+(imageWidth-2)+","+(imageHeight-2)+","+(dimLocal[2]-2)+") -> ("+(dimLocal[0]-2)+","+(dimLocal[1]-2)+","+(dimLocal[2]-2)+")");
		}
        for (int y = 0; y < dimLocal[1]; y++)
		{
			// progressMonitor
			IJ.showProgress ((double)y/dimLocal[1]);
			if (prgrMonitor.isCanceled())
			{  IJ.showProgress(100);
			   IJ.showStatus("");
			   return false;
			}
            prgrMonitor.setProgress(y);
            prgrMonitor.setNote((Math.round(((float)y/imageHeight)*100.0))+"%");

	        shiftY   = (int)(dimLocal[1]/2.0) - y;

			for (int x = 0; x < dimLocal[0]; x++)
	        {   // Rotate around the center of the image.
				shiftX   = (int)(dimLocal[0]/2.0) - x;
                fromX = (int)( ( shiftX * cosAngle) - ( shiftY * sinAngle) + imageWidth2);
                fromY = (int)( ( shiftX * sinAngle) + ( shiftY * cosAngle) + imageHeight2);

                if ( (fromX > -1) && (fromX < imageWidth)  && (fromY > -1) && (fromY < imageHeight) )
				   for (int zzz = 0; zzz < dimLocal[2]; zzz++)
					   img3Dtmp[x][y][zzz] = img3DRotating[fromX][fromY][zzz];
            } // End x loop.
        } // End y loop.


     prgrMonitor.close();
     IJ.showProgress(100);
	 img3DRotating = img3Dtmp;
	 img3Dtmp = null;
	 return true;
   }






   // --------------------------------------------------
   // re-compute the three slices

   public void Reslice()
   {
    	if (IJ.debugMode)
            IJ.write("DEBUG OrtView > Reslice("+wCurr+", "+hCurr+", "+zCurr+")");
        int tmp;

        // transaxial
	    int index = 0;
        tmp = zCurr-1; // arrays indeces start from 0!!
    	for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
    	    	pixTx[index++] = img3D[x][y][tmp];

        // coronal
    	index = 0;
        tmp = hCurr-1;
    	for (int y = 0; y < zCorr; y++)
            for (int x = 0; x < w; x++)
    	    	pixCr[index++] = img3D[x][tmp][y];

        // sagittal
    	index = 0;
        tmp = wCurr-1;
    	for (int y = 0; y < zCorr; y++)
            for (int x = 0; x < h; x++)
    	    	pixSg[index++] = img3D[tmp][x][y];

    }





   // --------------------------------------------------
   // compute the data array to display the VolumeView
   // The VolumeView is shown in a separate, ImageJ owned window:
   // it shows the three cuts in a common coordinate system

   public void ResliceVol()
   {
        // initializations...
        int pixVolDim = (w+zCorr)*(h+zCorr);
        int wVol = w+zCorr;
        int hVol = h+zCorr;
        int zCurrOffset;
        boolean east;  // true = show volume from NE ; false = from NW
        east = (wCurr > w/2) ? false : true;
    	if (IJ.debugMode)
        {   if (east) IJ.write("DEBUG OrtView > ResliceVol() from east");
            else IJ.write("DEBUG OrtView > ResliceVol() from west");
        }


        // set background to gray
        if (imgOrig.isInvertedLut())
		   for (int i=0; i<pixVolDim; i++)
			   pixVol[i] = 40;
        else for (int i=0; i<pixVolDim; i++)
            pixVol[i] = 215;







        // tx image
        int aux=0;
        if (east)   // copy tx image to pixVol, aligning it NE (to the right)
            for (int j=0; j<h; j++)
                for (int i=0; i<w; i++)
                    pixVol[j*(wVol)+(zCorr+i)] = pixTx[aux++];
        else        // copy tx image to pixVol, aligning it NW (to the left)
            for (int j=0; j<h; j++)
                for (int i=0; i<w; i++)
                    pixVol[j*(wVol)+i] = pixTx[aux++];



        // cr image
        // only write that part that will partially be covered by the sagittal section
        int hCurrOffset=hCurr-1;    // sweeps on pixVol
                                    // "-1" bc hCurr starts from 1, while ndxes on pixVol start from 0
                                    // the same holds for zCurrOffset below
        if (east)   // copy left part of cr image to pixVol, shrienking from SW to NE
        {  // zCurrOffset sweeps on pixCr
            for (zCurrOffset=zCurr-1, aux=0; zCurrOffset<zCorr; zCurrOffset++, aux++)
            {   for (int ww=0; ww<wCurr-1; ww++)
                    pixVol[hCurrOffset*wVol + zCorr-aux+ww] = pixCr[zCurrOffset*w + ww];
                hCurrOffset++;
                // external, horizontal border
                if (zCurrOffset==zCorr-1)
                {   hCurrOffset--; // step back...
                    for (int ww=0; ww<wCurr-1; ww++)
                        pixVol[hCurrOffset*wVol + zCorr-aux+ww] = 200;
                }
            }
            // internal, horizontal border
            for (int ww=0; ww<wCurr-1; ww++)
                pixVol[(hCurr-1)*wVol + zCorr+ww] = 0;
        }

        else // copy right part of cr image to pixVol, shrienking from SE to NW
        {   // zCurrOffset sweeps on pixCr
            for (zCurrOffset=zCurr-1, aux=0; zCurrOffset<zCorr; zCurrOffset++, aux++)
            {   for (int ww=wCurr; ww<w; ww++)
                    pixVol[hCurrOffset*wVol + ww+aux] = pixCr[zCurrOffset*w + ww];
                hCurrOffset++;
                // external, horizontal border
                if (zCurrOffset==zCorr-1)
                {   hCurrOffset--; // step back...
                    for (int ww=wCurr; ww<w; ww++)
                        pixVol[hCurrOffset*wVol + ww+aux] = 200;
                }
            }
            // internal, horizontal border
            for (int ww=wCurr; ww<w; ww++)
                pixVol[(hCurr-1)*wVol + ww] = 0;
        }






        // sg image
        int wCurrOffset=wCurr-1;    // sweeps on pixVol
                                    // "-1" bc wCurr starts from 1, while ndxes on pixVol start from 0
                                    // the same holds for zCurrOffset below
        if (east)   // copy cr image to pixVol, shrienking from NE to SW
        {   // zCurrOffset sweeps on pixSg
            for (zCurrOffset=zCurr-1, aux=0; zCurrOffset<zCorr; zCurrOffset++, aux++)
            {   for (int hh=0; hh<h; hh++)
                    pixVol[wVol*(hh+aux) + wCurrOffset+zCorr] = pixSg[zCurrOffset*h + hh];
                pixVol[wVol*aux + wCurrOffset+zCorr] = 200; // upper border
                wCurrOffset--;
                // add external border
                if (zCurrOffset==zCorr-1)
                {   wCurrOffset++;
                    for (int hh=0; hh<h; hh++)
                        pixVol[wVol*(hh+aux) + wCurrOffset+zCorr] = 200;
                }
            }
            // add internal border
            for (int hh=0; hh<h; hh++)
                pixVol[wVol*hh + wCurr-1+zCorr] = 0;
            }
        else   // copy cr image to pixVol, shrienking from NW to SE
        {   // zCurrOffset sweeps on pixCr
            for (zCurrOffset=zCurr-1, aux=0; zCurrOffset<zCorr; zCurrOffset++, aux++)
            {   for (int hh=0; hh<h; hh++)
                    pixVol[wVol*(hh+aux) + wCurrOffset] = pixSg[zCurrOffset*h + hh];
                pixVol[wVol*aux + wCurrOffset] = 200; // upper border
                wCurrOffset++;
                // add external border
                if (zCurrOffset==zCorr-1)
                {   wCurrOffset--; // step back...
                    for (int hh=0; hh<h; hh++)
                            pixVol[wVol*(hh+aux) + wCurrOffset] = 200;
               }
            }
            // add internal border
            for (int hh=0; hh<h; hh++)
                pixVol[wVol*hh + wCurr-1] = 0;
         }




        // cr image
        // (only the half that is in front of the sg one)
        hCurrOffset=hCurr-1;        // sweeps on pixVol
                                    // "-1" bc hCurr starts from 1, while ndxes on pixVol start from 0
                                    // the same holds for zCurrOffset below
        if (east)                   // copy right half of cr image to pixVol, shrienking from NE to SW
            // zCurrOffset sweeps on pixCr
        {   for (zCurrOffset=zCurr-1, aux=0; zCurrOffset<zCorr; zCurrOffset++, aux++)
            {   for (int ww=wCurr; ww<w; ww++)
                    pixVol[hCurrOffset*wVol + zCorr-aux+ww] = pixCr[zCurrOffset*w + ww];
                pixVol[hCurrOffset*wVol + zCorr-aux+wCurr-1] = 0;     // left, internal border
                pixVol[hCurrOffset*wVol + zCorr-aux+w-1] = 200;     // right, external border
                hCurrOffset++;
                // horizontal, external border
                if (zCurrOffset==zCorr-1)
                {   hCurrOffset--;                                  // step back...
                    for (int ww=wCurr; ww<w; ww++)
                        pixVol[hCurrOffset*wVol + zCorr-aux+ww] = 200;
                }
            }
            // internal, horizontal border
            for (int ww=wCurr; ww<w; ww++)
                pixVol[(hCurr-1)*wVol + zCorr+ww] = 0;
        }
        else // copy left part of cr image to pixVol, shrienking from NW to SE
            // zCurrOffset sweeps on pixCr
        {   for (zCurrOffset=zCurr-1, aux=0; zCurrOffset<zCorr; zCurrOffset++, aux++)
            {   for (int ww=0; ww<wCurr-1; ww++)
                    pixVol[hCurrOffset*wVol + ww+aux] = pixCr[zCurrOffset*w + ww];
                pixVol[hCurrOffset*wVol + wCurr-1+aux] = 0;         // right, internal border
                pixVol[hCurrOffset*wVol + aux] = 200;               // left , external border
                hCurrOffset++;
                // external, horizontal border
                if (zCurrOffset==zCorr-1)
                {   hCurrOffset--;                                  // step back...
                    for (int ww=0; ww<wCurr-1; ww++)
                        pixVol[hCurrOffset*wVol + ww+aux] = 200;
                }
            }
            // internal, horizontal border
            for (int ww=0; ww<wCurr-1; ww++)
                pixVol[(hCurr-1)*wVol + ww] = 0;
        }







   }



   // --------------------------------------------------
   // info...

   void showAbout() {
		IJ.showMessage("About OrtView ...",
			"OrtView shows the current stack image in an orthogonal view " +
            "consisting of a transaxial, a coronal and a sagittal section\n");
	}






   // --------------------------------------------------
   // Functions implementing the MouseListener Interface

    public void mousePressed (MouseEvent e)
    {
		synchronized (interpConsumer){
		synchronized (rotationConsumer)
		{  if (finishingInterpFlag) return;  // see note below, method mouseReleased()
		   if (finishingRotationFlag) return;
           wCurr = imgFrame.panTx.x_crss-imgFrame.panTx.x_offs+1;
           hCurr = imgFrame.panTx.y_crss-imgFrame.panTx.y_offs+1;
           zCurr = imgFrame.panCr.y_crss-imgFrame.panCr.y_offs+1;
		   if (IJ.debugMode)
              IJ.write("DEBUG OrtView > mousePressed: ("+imgFrame.panTx.x_crss+","+imgFrame.panTx.y_crss+","+imgFrame.panCr.y_crss+") -> img planes: ("+wCurr+","+hCurr+","+zCurr+")");
           Reslice ();
           imgFrame.computeImages(pixTx, pixCr, pixSg);
           imgFrame.showImages();
           imgFrame.drawCrosshairs();
		}
    }} // end of double synchronization on interpolation and rotation threads
	public void mouseClicked(MouseEvent e)
    {
	}
    public void mouseReleased (MouseEvent e)
    {
		synchronized (interpConsumer){
		synchronized (rotationConsumer)
		{  // the following is a really picky check against the following rare case:
			// interp.Thread is running while user is playing around with the crosshair.
			// panXX_mousePressed (or panXX_mouseReleased) has already been executed
			// but before this section can start, the synchronized section of
			// one of the computeImg3DXXX interpolation methods is entered:
			// there, imgFrame is updated, along with the dimensions of the new views.
			// hence, [w|h|z]Curr here become inconsistent. The way I deal with this
			// is simply to exit without updating the crossHair and forget about the
			// inconsistency.
			// Of course, there still is the possibility left over that this thread
			// delays for some reason and doesn't get to be executed until
			// finishingInterpFlag is again set to false when the interp.Thread exits.
			// Well, this has such a remote chance to happen that I hope nobody minds if
			// I don't deal such a case. I know, this is not perfect programming...
			// A similar idea also applies to "finishingRotationFlag" and the rotation thread
			if (finishingInterpFlag) return;
			if (finishingRotationFlag) return;
           wCurr = imgFrame.panTx.x_crss-imgFrame.panTx.x_offs+1;
           hCurr = imgFrame.panTx.y_crss-imgFrame.panTx.y_offs+1;
           zCurr = imgFrame.panCr.y_crss-imgFrame.panCr.y_offs+1;
		   if (IJ.debugMode)
		      IJ.write("DEBUG OrtView > mouseReleased: ("+imgFrame.panTx.x_crss+","+imgFrame.panTx.y_crss+","+imgFrame.panCr.y_crss+") -> img planes: ("+wCurr+","+hCurr+","+zCurr+")");
           Reslice ();
		   imgFrame.computeImages(pixTx, pixCr, pixSg);
		   imgFrame.showImages();
		   imgFrame.drawCrosshairs();
		}}  // end of double synchronization on interpolation and rotation threads
    }
	public void mouseEntered(MouseEvent e)
    {
    }
	public void mouseExited(MouseEvent e)
    {   IJ.showStatus("");
	}





   // --------------------------------------------------
   // Functions implementing the MouseMotionListener Interface

	public void mouseDragged(MouseEvent e)
    {
	}
   	public void mouseMoved(MouseEvent e)
    {      if (e.getSource() == imgFrame.panTx)
           {    int locX=e.getX()-imgFrame.panTx.x_offs+1;
                int locY=e.getY()-imgFrame.panTx.y_offs+1;
                if ((locX>0)&&(locX<=w) && (locY>0)&&(locY<=h))
                    IJ.showStatus (zCurr+"th transaxial plane, Location = ("+locX+", "+locY+"), Value = "+pixTx[(locY-1)*w+locX-1]+")");
                else IJ.showStatus("");
           }
           if (e.getSource() == imgFrame.panCr)
           {    int locX=e.getX()-imgFrame.panCr.x_offs+1;
                int locY=e.getY()-imgFrame.panCr.y_offs+1;
                if ((locX>0)&&(locX<=w) && (locY>0)&&(locY<=zCorr))
                    IJ.showStatus (hCurr+"th coronal plane, Location = ("+locX+", "+locY+"), Value = "+pixCr[(locY-1)*w+locX-1]+")");
                else IJ.showStatus("");
           }
           if (e.getSource() == imgFrame.panSg)
           {    int locX=e.getX()-imgFrame.panSg.x_offs+1;
                int locY=e.getY()-imgFrame.panSg.y_offs+1;
                if ((locX>0)&&(locX<=h) && (locY>0)&&(locY<=zCorr))
                    IJ.showStatus (wCurr+"th sagittal plane, Location = ("+locX+", "+locY+"), Value = "+pixSg[(locY-1)*h+locX-1]+")");
                else IJ.showStatus("");
           }
    }






   // --------------------------------------------------
   // Implements the ActionListener Interface for the menuBar
   // for each menutItem being activated it calls an appropriate function

    public void actionPerformed(ActionEvent e)
    {   Object o = e.getSource();

        if (IJ.debugMode)
            IJ.write ("DEBUG OrtViewMenu > "+e.getActionCommand());

        // File -> Open Configuration...
        if (o == imgFrame.menuBar.menuItemOpen)
		{   // I dunno why this jurky programming seems to be the only way
			// not to have it.join() in method actionOpenConf() crash ImageJ
			Thread opConfT = new Thread (new Runnable ()
			{     public void run ()
					{	  actionOpenConf(); }
			});
			opConfT.start();
		}

        // File -> Save Configuration...
        else if (o == imgFrame.menuBar.menuItemSave)
            actionSaveConf();

        // File -> Export Transaxial Image
        else if (o == imgFrame.menuBar.menuItemExpTxImg)
            actionExpTxImg();

        // File -> Export Coronal Image
        else if (o == imgFrame.menuBar.menuItemExpCrImg)
            actionExpCrImg();

        // File -> Export Sagittal Image
        else if (o == imgFrame.menuBar.menuItemExpSgImg)
            actionExpSgImg();

        // File -> Export all three Images
        else if (o == imgFrame.menuBar.menuItemExp3Img)
            actionExpAllImg();

        // File -> Export Transaxial Stack
        else if (o == imgFrame.menuBar.menuItemExpTxStk)
            actionExpTxStack();

        // File -> Export Coronal Stack
        else if (o == imgFrame.menuBar.menuItemExpCrStk)
             actionExpCrStack();

        // File -> Export Sagittal Stack
        else if (o == imgFrame.menuBar.menuItemExpSgStk)
             actionExpSgStack();

        // File -> Export all Stack
        else if (o == imgFrame.menuBar.menuItemExp3Stk)
        {    actionExpTxStack();
             actionExpCrStack();
             actionExpSgStack();
        }

        // File -> Quit OrtView
        else if (o == imgFrame.menuBar.menuItemQuitOrtview)
        {
			imgFrame.dispose();
            IJ.write("\n\nOrtView Exit\n========================================\n");
            return;
        }

        // Process -> Interpolate...
        else if (o == imgFrame.menuBar.menuItemInterpolate)
        {
			// warning
			IJ.write ("WARNING: Interpolation is applied to the original volume.\n   Any operation performed on the volume, such as rotation or smoothing, won't be considered");

			// show Interpolation dialog
            OrtViewInterpSettings dlg = new OrtViewInterpSettings(measurementUnit, interpType, zSpacing, voxel_xDim, voxel_zDim);
            Dimension dlgSize = dlg.getPreferredSize();
            Dimension frmSize = imgFrame.getSize();
            Point loc = imgFrame.getLocation();
            dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
            dlg.setModal(true);
            dlg.show();
            if (dlg.zSpacing >0) // by convention zSpacing is set to negative if user pressed OK and img needs to be recomputed
		    {	IJ.showStatus ("OrtView");
		        return;
			}

            // run interpolation
            interpConsumer.dlg = dlg;
            Thread t = new Thread (interpConsumer);
            t.start();
			return;
        }


        // Process -> Smooth : smooth img over three pixel on an axial segment
        else if (o == imgFrame.menuBar.menuItemSmooth3)
	    {   actionSmooth3Img();
            Reslice();
            imgFrame.computeImages(pixTx, pixCr, pixSg);
            imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
            imgFrame.showImages();
            imgFrame.drawCrosshairs();
		}

        // Process -> Smooth : smooth img over a 2x2x2 pixel neighborhood
        else if (o == imgFrame.menuBar.menuItemSmooth8)
	    {   actionSmooth8Img();
            Reslice();
            imgFrame.computeImages(pixTx, pixCr, pixSg);
		    imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
            imgFrame.showImages();
            imgFrame.drawCrosshairs();
		}

        // Process -> Smooth : smooth img over a 2x2x2 pixel neighborhood
        else if (o == imgFrame.menuBar.menuItemSmooth27)
	    {   IJ.error ("....ops! 'Currently out of office. Please check by later");
	    }

        // Process -> Rotate : rotate the volume
        else if (o == imgFrame.menuBar.menuItemRotate)
        {   // show Rotation dialog
            OrtViewRotationSettings dlg = new OrtViewRotationSettings(rotationAngleW, rotationAngleH, rotationAngleZ, rotationSequence);
            Dimension dlgSize = dlg.getPreferredSize();
            Dimension frmSize = imgFrame.getSize();
            Point loc = imgFrame.getLocation();
            dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
            dlg.setModal(true);
            dlg.show();
            if (dlg.rotationAngleW >0) // by convention rotationAngleW is set to negative if user pressed OK and img needs to be recomputed
		    {	IJ.showStatus ("OrtView");
		        return;
			}

            // run interpolation
            rotationConsumer.dlg = dlg;
            Thread t = new Thread (rotationConsumer);
            t.start();
			return;
        }


		// Process -> Undo Rotation : brings image back to what it looked like before the first rotation
        else if (o == imgFrame.menuBar.menuItemUndoRotate)
            actionUndoRotate();



        // Process -> Reset : reset the views as they were when the plugin was started
        else if (o == imgFrame.menuBar.menuItemReset)
            actionReset();


        // Options -> Vertical Orientation Choice
        else if (o == imgFrame.menuBar.menuItemNuclMed)
        {   if (vertOrientationChoice == 1) // orientation was switched (Radiology -> Nucl Med)
            {   imgFrame.menuBar.vertOrientationChoice = 0;
                imgFrame.menuBar.switchVertOrientationChoice();
                vertOrientationChoice = 0;
                // recompute and repaint image
                if (IJ.debugMode)
                    IJ.write ("DEBUG OrtView > Orientation switched to "+vertOrientationChoice);
                actionVertOrientation();
	            Reslice();
                imgFrame.computeImages (pixTx, pixCr, pixSg);
                imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
                imgFrame.showImages ();
                imgFrame.drawCrosshairs();
            } // else don't do anything
        }

        // Options -> Vertical Orientation Choice
        else if (o == imgFrame.menuBar.menuItemRadiology)
        {   if (vertOrientationChoice == 0) // orientation was switched (Nucl Med -> Radiology)
            {   imgFrame.menuBar.vertOrientationChoice = 1;
                imgFrame.menuBar.switchVertOrientationChoice();
                vertOrientationChoice = 1;
                // recompute and repaint image
                if (IJ.debugMode)
                    IJ.write ("DEBUG OrtView > Orientation switched to "+vertOrientationChoice);
				actionVertOrientation();
				Reslice();
                imgFrame.computeImages (pixTx, pixCr, pixSg);
                imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
                imgFrame.showImages ();
                imgFrame.drawCrosshairs();
            } // else don't do anything
        }

        // Options -> Volume View
        else if (o == imgFrame.menuBar.menuItemVolView)
        {   ResliceVol();
            actionVolumeView();
        }

        // Options -> Crosshair...
        else if (o == imgFrame.menuBar.menuItemCrosshair)
        {   OrtViewCrosshairSettings dlg = new OrtViewCrosshairSettings(wCurr, hCurr, zCurr, w, h, zCorr);
            Dimension dlgSize = dlg.getPreferredSize();
            Dimension frmSize = imgFrame.getSize();
            Point loc = imgFrame.getLocation();
            dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
            dlg.setModal(true);
            dlg.show();
            if (dlg.wCurr>0) // by convention wCurr is set to neg if OK was pressed and img needs to be recomputed
            {   if (IJ.debugMode)
                    IJ.write ("DEBUG OrtView > New Crosshair Location: exit w/out OK");
				IJ.showStatus ("OrtView");
                return;
            }
            // grab values
            if ((wCurr == -dlg.wCurr) && (hCurr == dlg.hCurr) && (zCurr == dlg.zCurr))
            {  IJ.showStatus ("OrtView");
			   if (IJ.debugMode)
                  IJ.write ("DEBUG OrtView > New Crosshair Location: nothing was changed");
                return;
            }
		    wCurr = -dlg.wCurr;
            hCurr = dlg.hCurr;
            zCurr = dlg.zCurr;
		    if (IJ.debugMode)
                IJ.write ("DEBUG OrtView > New Crosshair Location: ("+wCurr+
                ","+hCurr+","+zCurr+")");
            Reslice ();
            imgFrame.computeImages(pixTx, pixCr, pixSg);
	        imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
            imgFrame.showImages();
            imgFrame.drawCrosshairs();
        }


        // Options -> Auto adjust Brightness/Contrast...
        else if (o == imgFrame.menuBar.menuItemAdjustBC)
		{   /* old method: invoke ImageJ Menu command on original image
			this doesn't work, cuz command runs in a separate thread
			and I can't know when it is done...

			// first set the one ImageJ image to be active
			// on which the current session of OrtView was started
			WindowManager.setCurrentWindow(imgOrig.getWindow());
			// run ImageJ Menu command "Image -> Adjust -> Brightness/Contrast..." on that image
			IJ.run("Brightness/Contrast...");
			// retrieve updates (colorModel?LUT?) and apply it to the OrtView panels

			*/

			// rescale pixel values
			actionAutoAdjustBC();
	        Reslice();
            imgFrame.computeImages (pixTx, pixCr, pixSg);
            imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
            imgFrame.showImages ();
            imgFrame.drawCrosshairs();


	 		if (IJ.debugMode)
			   IJ.write ("DEBUG OrtView > return from <Auto adjust B/C>");
		}


		IJ.showStatus ("OrtView");
    }






   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Open Configuration...

    private void actionOpenConf()
    {
            // the following keep track of what needs to be executed once
            // the new parameters have been loaded:
            // NTH nothing
            // NEW_CRSH new crosshair location -> reslice and repaint images
			// NEW_ORNT new orientation -> swap orientation, reslice and repaint
            // NEW_INTRP new interpolation -> run interp.thread
			// NEW_ROT new rotation -> run rotation thread

			final byte NTH = 0;            // 0000 0000
			final byte NEW_ORNT = 1;       // 0000 0001
			final byte NEW_INTRP = 2;      // 0000 0010
			final byte NEW_ROT = 4;        // 0000 0100
			final byte NEW_CRSH = 8;       // 0000 1000
            byte WhatChanged = NTH;

			// these dialogs will never show up here. They are just created to pass
			// values to the interp or rotation Thread respectively
			// which expect such an object...
            OrtViewInterpSettings dlg = new OrtViewInterpSettings(measurementUnit, interpType, zSpacing, voxel_xDim, voxel_zDim);
			OrtViewRotationSettings dlgRot = new OrtViewRotationSettings(rotationAngleW, rotationAngleH, rotationAngleZ, rotationSequence);

			// backup values
			int wCurrBackup, hCurrBackup, zCurrBackup;


            // user chooses file
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle ("Open Configuration...");
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int returnVal = chooser.showOpenDialog(imgFrame);
            if (returnVal != JFileChooser.APPROVE_OPTION)
                return;
            File openFile = chooser.getSelectedFile();


            // check file
			if (openFile == null)
			   IJ.error("Error: could not get file");
            if (!openFile.canRead())
                IJ.error("Error: can not read from file "+openFile.getName());
            DataInputStream openInput;
            try
            {   openInput = new DataInputStream (new FileInputStream(openFile));
            }
            catch (FileNotFoundException e)
            {   IJ.error ("Error: cannot open file "+openFile.getName()+" for reading");
                return;
            }


            // read from file and check what values are different from current ones
            // (hence, what needs to be recomputed)
            try
            {
                // Orientation
                int tmp = openInput.readInt();
                if (tmp != vertOrientationChoice)
                    WhatChanged |= NEW_ORNT;
                vertOrientationChoice = tmp;

                // Interpolation
				// I need to backup current values, in case interpolation
				// is performed later and user cancels it while it is being computed
				dlg.interpType = openInput.readInt();
                // Linear Interpolation
				dlg.zSpacing = -openInput.readInt();
                // Spline or Polynomial Interpolation
				dlg.voxel_xDim = openInput.readDouble();
				dlg.voxel_zDim = openInput.readDouble();
                // test whether interpolation needs to be recomputed:
				// it needs to be recomputed if:
				if (dlg.interpType == 0)       // new interpType is linear,
				{  if ((interpType != 0) ||       // but old was s.th. else, or
					(zSpacing != -dlg.zSpacing))   // old is also linear, but with different zSpacing
                       WhatChanged |= NEW_INTRP;
				}
				else                            // new interpType is not linear
				   if ((interpType!=dlg.interpType) || // and at least 1 param differs from old settings
					  (voxel_xDim!=dlg.voxel_xDim) || (voxel_zDim!=dlg.voxel_zDim) )
					  WhatChanged |= NEW_INTRP;

				// rotation
				// backup current values, in case users cancels rotation
				// while it is being computed
				dlgRot.rotationSequence = openInput.readInt();
				dlgRot.rotationAngleW = -openInput.readInt();
				dlgRot.rotationAngleH = openInput.readInt();
				dlgRot.rotationAngleZ = openInput.readInt();
                // test whether rotation needs to be recomputed:
				if ((dlgRot.rotationSequence != rotationSequence) ||
				    (dlgRot.rotationAngleW != rotationAngleW) ||
				    (dlgRot.rotationAngleH != rotationAngleH) ||
				    (dlgRot.rotationAngleZ != rotationAngleZ))
					  WhatChanged |= NEW_ROT;

                // Crosshair position
                wCurrBackup = openInput.readInt();
                if (wCurrBackup != wCurr)
                    WhatChanged |= NEW_CRSH;
                hCurrBackup = openInput.readInt();
                if (hCurrBackup != hCurr)
                    WhatChanged |= NEW_CRSH;
                zCurrBackup = openInput.readInt();
                if (zCurrBackup != zCurr)
                    WhatChanged |= NEW_CRSH;

                openInput.close();
                if (IJ.debugMode)
                {   IJ.write("DEBUG OrtView > Open Configuration: wCurr="+wCurrBackup+", hCurr="+hCurrBackup+", zCurr="+zCurrBackup+", zSpacing="+dlg.zSpacing);
                    IJ.write("DEBUG OrtView > Open Configuration: voxel_xDim="+dlg.voxel_xDim+", voxel_zDim="+dlg.voxel_zDim);
                    IJ.write("DEBUG OrtView > Open Configuration: interpType="+dlg.interpType+", vertOr.Choice="+vertOrientationChoice);
                }
            }
            catch (IOException ee)
            {   IJ.error("Error reading from file "+openFile.getName());
				return;
            }


            // Depending on what values are different from the previously active one,
            // perform specific tasks in order to update the views

			// Note, that the four actions ORNT, INTRP, ROT and CRSH, have to be performed
			// in a specific order (if to be performed at all, i.e. if their settings
			// as saved on file are different from the currently active ones).
			// In fact, crosshair location strictly depends on both image dimension and
			// orientation that change according to INTRP, ROT and ORNT respectively.
			// For this reason, CRSH has to be set as last, which forbids to run ROT and
			// INTRP as a separate, parallel thread (this would certainly be more
			// convenient to the user, though).

            if (WhatChanged == NTH)       // nothing was modified
            {   if (IJ.debugMode)
                   IJ.write("DEBUG OrtView > Open Configuration but nothing was modified...");
                return;
            }



			// Vertical Orientation changed

            if ((WhatChanged & NEW_ORNT) > 0)
			{   if (IJ.debugMode)
				   IJ.write ("DEBUG OrtView > Open Configuration: New Vertical Orientation");
				imgFrame.menuBar.vertOrientationChoice = vertOrientationChoice;
                imgFrame.menuBar.switchVertOrientationChoice();
			    actionVertOrientation();
				Reslice ();
                imgFrame.computeImages(pixTx, pixCr, pixSg);
	            imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
                imgFrame.showImages();
                imgFrame.drawCrosshairs();
			}



			// re-interpolate

            if ((WhatChanged & NEW_INTRP) > 0)
            {
		        if (IJ.debugMode)
                {   if (dlg.interpType == 0)
                        IJ.write ("DEBUG OrtView > Open Configuration: New linear interpolation settings: zSpacing = "+(-dlg.zSpacing));
                    else
                        IJ.write ("DEBUG OrtView > Open Configuration: New interpolation settings: voxel dimension = ("+dlg.voxel_xDim+", "+dlg.voxel_xDim+", "+dlg.voxel_zDim+")");
                }

				// don't proceed with execution until Interp.Thread finishes
				// (interpolation needs to be finished in order to have the new image
				// dimensions and thus correctly rotate the volume and set the crosshair)
				interpConsumer.dlg = dlg;
				if (IJ.debugMode)
				{	IJ.write("\nDEBUG Current Thread:\nDEBUG    Name = "+Thread.currentThread().getName());
					IJ.write("DEBUG    Priority = "+Thread.currentThread().getPriority());
					IJ.write("DEBUG    Group Name = "+Thread.currentThread().getThreadGroup().getName());
					IJ.write("DEBUG    Active Count = "+Thread.currentThread().activeCount()+"\n");
				}
				generalFlag = 1;
				Thread it = new Thread (interpConsumer);
				it.start();
				computingInterpolationFlag = true;
				while (computingInterpolationFlag == true)
				{     try
				      {
						it.join();
						it = null;
					  }
					  catch (InterruptedException e) {}
				}
				if (generalFlag < 0) // signals that interpolation was canceled by user
				{    // in which case, don't set the new crsh
					 WhatChanged &= (~NEW_CRSH);
					 generalFlag = 1;
				}

            } // end of case NEW_INTRP



			// re-rotate

            if ((WhatChanged & NEW_ROT) > 0)
            {
		        if (IJ.debugMode)
                        IJ.write ("DEBUG OrtView > Open Configuration: New rotation settings");

				// don't proceed with execution until Rotation.Thread finishes
				// (interpolation needs to be finished in order to have the new
				// image dimensions and orientation and thus correctly set the crosshair)
				rotationConsumer.dlg = dlgRot;
				if (IJ.debugMode)
				{	IJ.write("\nDEBUG Current Thread:\nDEBUG    Name = "+Thread.currentThread().getName());
					IJ.write("DEBUG    Priority = "+Thread.currentThread().getPriority());
					IJ.write("DEBUG    Group Name = "+Thread.currentThread().getThreadGroup().getName());
					IJ.write("DEBUG    Active Count = "+Thread.currentThread().activeCount()+"\n");
				}
				generalFlag = 1;
				Thread rt = new Thread (rotationConsumer);
				rt.start();
				computingRotationFlag = true;
				while (computingRotationFlag == true)
				{     try
				      {
						rt.join();
						rt = null;
					  }
					  catch (InterruptedException e) {}
				}
				if (generalFlag < 0) // signals that rotation was canceled by user
				{    // in which case, don't proceed with setting the new crsh
					 // WhatChanged &= (~NEW_CRSH);
					 generalFlag = 1;
					 return;
				}

            } // end of case NEW_ROT




			// set new crosshair

			if ((WhatChanged & NEW_CRSH)  > 0)
			{   // if interpolation was not aborted, then execution can proceed with
				// setting the new crosshair, which includes updating the global variables
				wCurr = wCurrBackup;
				hCurr = hCurrBackup;
				zCurr = zCurrBackup;
				if (IJ.debugMode)
			       IJ.write ("DEBUG OrtView > New crosshair location: ("+wCurr+","+hCurr+","+zCurr+")");
				Reslice ();
                imgFrame.computeImages(pixTx, pixCr, pixSg);
	            imgFrame.setCrosshairs(wCurr, hCurr, zCurr);
                imgFrame.showImages();
                imgFrame.drawCrosshairs();
            }

    }








   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Save Configuration...

    private void actionSaveConf()
    {
            // user chooses file
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle ("Save Configuration...");
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int returnVal = chooser.showSaveDialog(imgFrame);
            if (returnVal != JFileChooser.APPROVE_OPTION)
                return;
            File saveFile = chooser.getSelectedFile();

            // check file
            if (saveFile.exists())
            {   GenericDialog gd = new GenericDialog("Warning");
                gd.addMessage(saveFile.getName()+" exists. Overwrite?");
                gd.showDialog();
                if (gd.wasCanceled())
                    return;
                if (!saveFile.canWrite())
                    IJ.error("Error: can not write to file "+saveFile.getName());
            }
            DataOutputStream saveOutput;
            try
            {   saveOutput = new DataOutputStream (new FileOutputStream(saveFile));
            }
            catch (FileNotFoundException e)
            {   IJ.error ("Error: cannot open file "+saveFile.getName()+" for writing");
                return;
            }

            // write to file
            try
            {   saveOutput.writeInt(vertOrientationChoice); // Orientation
                saveOutput.writeInt(interpType);            // Interpolation
                saveOutput.writeInt(zSpacing);
                saveOutput.writeDouble(voxel_xDim);
                saveOutput.writeDouble(voxel_zDim);
				saveOutput.writeInt(rotationSequence);      // rotation
				saveOutput.writeInt(rotationAngleW);
				saveOutput.writeInt(rotationAngleH);
				saveOutput.writeInt(rotationAngleZ);
                saveOutput.writeInt(wCurr);                 // crosshair
                saveOutput.writeInt(hCurr);
                saveOutput.writeInt(zCurr);
                saveOutput.close();
            }
            catch (IOException ee)
            {   IJ.error("Error writing to file "+saveFile.getName());
            }
    }




   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export Tx Img

    private void actionExpTxImg()
    {
            ImagePlus ExpTxImg;
            if (imgOrig.getType() == ImagePlus.GRAY8)        // Byte image
                ExpTxImg = NewImage.createByteImage("Transaxial Plane",w,h,1,NewImage.FILL_RAMP);
            else // imgOrig.getType() == ImagePlus.GRAY16    // Short image
                ExpTxImg = NewImage.createShortImage("Transaxial Plane",w,h,1,NewImage.FILL_RAMP);
            ExpTxImg.show();
            ImageProcessor ExpTIP = ExpTxImg.getProcessor();
            int index=0;
            for (int j=0; j<h; j++)
                for (int i=0; i<w; i++)
                    ExpTIP.putPixel(i, j, pixTx[index++] );
            ExpTIP.setColorModel(cModel);
            ExpTIP.resetMinAndMax();
            ExpTxImg.updateAndDraw();
    }






   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export Cr Img

    private void actionExpCrImg()
    {
            ImagePlus ExpCrImg;
            if (imgOrig.getType() == ImagePlus.GRAY8)        // Byte image
                ExpCrImg = NewImage.createByteImage("Coronal Plane",w,zCorr,1,NewImage.FILL_RAMP);
            else // imgOrig.getType() == ImagePlus.GRAY16    // Short image
                ExpCrImg = NewImage.createShortImage("Coronal Plane",w,zCorr,1,NewImage.FILL_RAMP);
            ExpCrImg.show();
            ImageProcessor ExpCIP = ExpCrImg.getProcessor();
            int index=0;
            for (int j=0; j<zCorr; j++)
                for (int i=0; i<w; i++)
                    ExpCIP.putPixel(i, j, pixCr[index++] );
            ExpCIP.setColorModel(cModel);
            ExpCIP.resetMinAndMax();
            ExpCrImg.updateAndDraw();
    }





   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export Sg Img

    private void actionExpSgImg()
    {
            ImagePlus ExpSgImg;
            if (imgOrig.getType() == ImagePlus.GRAY8)        // Byte image
                ExpSgImg = NewImage.createByteImage("Sagittal Plane",h,zCorr,1,NewImage.FILL_RAMP);
            else // imgOrig.getType() == ImagePlus.GRAY16    // Short image
                ExpSgImg = NewImage.createShortImage("Sagittal Plane",h,zCorr,1,NewImage.FILL_RAMP);
            ExpSgImg.show();
            ImageProcessor ExpSIP = ExpSgImg.getProcessor();
            int index=0;
            for (int j=0; j<zCorr; j++)
                for (int i=0; i<h; i++)
                    ExpSIP.putPixel(i, j, pixSg[index++] );
            ExpSIP.setColorModel(cModel);
            ExpSIP.resetMinAndMax();
            ExpSgImg.updateAndDraw();
    }





   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export all three Imgs

    private void actionExpAllImg()
    {
            ImagePlus ExpTxImg, ExpCrImg, ExpSgImg;
            if (!imgTypeShort)      // Byte image
            {   ExpTxImg = NewImage.createByteImage("Transaxial Plane",w,h,1,NewImage.FILL_RAMP);
                ExpCrImg = NewImage.createByteImage("Coronal Plane",w,zCorr,1,NewImage.FILL_RAMP);
                ExpSgImg = NewImage.createByteImage("Sagittal Plane",h,zCorr,1,NewImage.FILL_RAMP);
            }
            else                    // Short image
            {   ExpTxImg = NewImage.createShortImage("Transaxial Plane",w,h,1,NewImage.FILL_RAMP);
                ExpCrImg = NewImage.createShortImage("Coronal Plane",w,zCorr,1,NewImage.FILL_RAMP);
                ExpSgImg = NewImage.createShortImage("Sagittal Plane",h,zCorr,1,NewImage.FILL_RAMP);
            }
            ExpTxImg.show();
            ExpCrImg.show();
            ExpSgImg.show();
            ImageProcessor ExpTIP = ExpTxImg.getProcessor();
            ImageProcessor ExpCIP = ExpCrImg.getProcessor();
            ImageProcessor ExpSIP = ExpSgImg.getProcessor();

            int indext=0, indexc=0, indexs=0;
            for (int j=0; j<h; j++)            // transaxial
                for (int i=0; i<w; i++)
                    ExpTIP.putPixel(i, j, pixTx[indext++]);
            for (int j=0; j<zCorr; j++)
            {   for (int i=0; i<w; i++)        // coronal
                    ExpCIP.putPixel(i, j, pixCr[indexc++]);
                for  (int i=0; i<h; i++)       // sagittal
                    ExpSIP.putPixel(i, j, pixSg[indexs++]);
            }
            ExpTIP.setColorModel(cModel);
            ExpCIP.setColorModel(cModel);
            ExpSIP.setColorModel(cModel);
            ExpTIP.resetMinAndMax();
            ExpCIP.resetMinAndMax();
            ExpSIP.resetMinAndMax();
            ExpTxImg.updateAndDraw();
            ExpCrImg.updateAndDraw();
            ExpSgImg.updateAndDraw();
    }




   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export Tx Stack

    private void actionExpTxStack()
    {
            ImageStack ExpTxStack = new ImageStack (w,h);
			ImagePlus ExpTxImg;

            for (int q=0; q<zCorr; q++)
            {
                if (!imgTypeShort)          // Byte image
				   ExpTxImg = NewImage.createByteImage("Transaxial Stack",w,h,1,NewImage.FILL_RAMP);
                else // Short image
				   ExpTxImg = NewImage.createShortImage("Transaxial Stack",w,h,1,NewImage.FILL_RAMP);
				ImageProcessor ExpTIP = ExpTxImg.getProcessor();
                int index=0;
                for (int j=0; j<h; j++)
                    for (int i=0; i<w; i++)
                        ExpTIP.putPixel(i, j, img3D[i][j][q] );
                ExpTIP.resetMinAndMax();
                /* actually, don't change plane order...
                if (vertOrientationChoice == 1) // Radiology
                   ExpTxStack.addSlice(null, ExpTIP, 0);
                else */ExpTxStack.addSlice(null, ExpTIP); // Nuclear Medicine
            }
            ExpTxStack.setColorModel(cModel);
            ImagePlus imp = new ImagePlus("Transaxial Stack", ExpTxStack);
            imp.show();
    }





   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export Cr Stack

    private void actionExpCrStack()
    {
            ImageStack ExpCrStack = new ImageStack (w,zCorr);
			ImagePlus ExpCrImg;

            for (int j=0; j<h; j++)
            {
                if (!imgTypeShort)          // Byte image
				   ExpCrImg = NewImage.createByteImage("Coronal Stack",w,zCorr,1,NewImage.FILL_RAMP);
                else                        // Short image
				   ExpCrImg = NewImage.createShortImage("Coronal Stack",w,zCorr,1,NewImage.FILL_RAMP);
                ImageProcessor ExpCIP = ExpCrImg.getProcessor();
                int index=0;
                for (int q=0; q<zCorr; q++)
                   for (int i=0; i<w; i++)
                        ExpCIP.putPixel(i, q, img3D[i][j][q] );
                ExpCIP.resetMinAndMax();
                ExpCrStack.addSlice(null, ExpCIP);
            }
            ExpCrStack.setColorModel(cModel);
            ImagePlus imp = new ImagePlus("Coronal Stack", ExpCrStack);
            imp.show();
    }


   // --------------------------------------------------
   // Action to perform when user calls Menu : File -> Export Sg Stack

    private void actionExpSgStack()
    {
            ImageStack ExpSgStack = new ImageStack (h,zCorr);
			ImagePlus ExpSgImg;

            for (int i=0; i<w; i++)
            {
                if (!imgTypeShort)          // Byte image
				   ExpSgImg = NewImage.createByteImage("Sagittal Stack",h,zCorr,1,NewImage.FILL_RAMP);
                else                        // Short image
				   ExpSgImg = NewImage.createShortImage("Sagittal Stack",h,zCorr,1,NewImage.FILL_RAMP);
                ImageProcessor ExpSIP = ExpSgImg.getProcessor();
                int index=0;
                for (int q=0; q<zCorr; q++)
                    for (int j=0; j<h; j++)
                        ExpSIP.putPixel(j, q, img3D[i][j][q] );
                ExpSIP.resetMinAndMax();
                ExpSgStack.addSlice(null, ExpSIP);
            }
            ExpSgStack.setColorModel(cModel);
            ImagePlus imp = new ImagePlus("Sagittal Stack", ExpSgStack);
            imp.show();
    }





   // --------------------------------------------------
   // Replaces each internal pixel with the 3x3x3 neighborhood mean
   // This corresponds to the ImageJ 2D function ImageProcessor:smooth()

   private void actionSmooth27Img()
   {    /* img3D needs to be copied into a imgTmp vector from which to
           extract the pixel values to compute the mean; otherwise,
           half of the pixel of the neighborhood would already have been
           "smoothed"...
           Also note that 6 planes have to be skipped in the loops,
           namely two in each directions: only internal pixels have to be
           considered in order to always have a 27 pixel neighborhood
        */
    }




   // --------------------------------------------------
   // Replaces each internal pixel with the 2x2x2 neighborhood mean
   // This is a much faster function than smooth27Img()
   // Moreover, since it smoothes less than smooth27Img() it also drops out
   // less detail which might be of relevance in some cases...

   private void actionSmooth8Img()
   {
        int kkk, iii, jjj;

        if (IJ.debugMode)
           IJ.write ("DEBUG OrtView > actionSmooth8Img()");

		for (kkk = 0; kkk < zCorr-1; kkk++)     // skip last border plane in each of the 3 directions
			for (iii = 0; iii < w-1; iii++)
                for (jjj = 0; jjj < h-1; jjj++)
                    img3D[iii][jjj][kkk] =
                       (img3D[iii][jjj+1][kkk+1]+img3D[iii+1][jjj][kkk]+
                       img3D[iii+1][jjj][kkk+1]+img3D[iii][jjj+1][kkk]+
                       img3D[iii+1][jjj+1][kkk]+img3D[iii][jjj][kkk+1]+
                       img3D[iii][jjj][kkk]+img3D[iii+1][jjj+1][kkk+1])/8;

   }








   // --------------------------------------------------
   // Replaces each pixel of each internal tx plane with the mean of
   // the axial, 3 pixel segment.

   private void actionSmooth3Img()
   {
        int kkk, iii, jjj;

        if (IJ.debugMode)
           IJ.write ("DEBUG OrtView > actionSmooth3Img()");

        for (kkk = 1; kkk < zCorr-1; kkk++)     // skip last border plane in each of the 3 directions
		    for (iii = 0; iii < w-1; iii++)
                for (jjj = 0; jjj < h-1; jjj++)
					img3D[iii][jjj][kkk] = (img3D[iii][jjj][kkk+1]+
										 img3D[iii][jjj][kkk-1]+img3D[iii][jjj][kkk])/3;
			// now handle first plane...
        for (iii = 0; iii < w-1; iii++)
			for (jjj = 0; jjj < h-1; jjj++)
				img3D[iii][jjj][0] = (img3D[iii][jjj][1]+
									   img3D[iii][jjj][0])/2;
			// ...and last one
        for (iii = 0; iii < w-1; iii++)
			for (jjj = 0; jjj < h-1; jjj++)
				img3D[iii][jjj][zCorr-1] = (img3D[iii][jjj][zCorr-1]+
									 img3D[iii][jjj][zCorr-2])/2;
   }           // actionSmooth3Img()






   // --------------------------------------------------
   // Action to perform when user calls Menu Process -> Undo Rotation
   // resets the volume to what it looked like before any rotation had taken place

    private void actionUndoRotate()
    {
        if (IJ.debugMode)
            IJ.write("\nDEBUG OrtView > actionUndoRotate()");

		img3D = img3DUnrotated;
		w = wOrig;
		h = hOrig;
		zCorr = zCorrUnrotated;
		rotationAngleW = 0;
		rotationAngleH = 0;
		rotationAngleZ = 0;
		imgRotated = false;
		img3DUnrotated = null;
		imgFrame.menuBar.menuItemUndoRotate.setEnabled(imgRotated);

		if (imgFrame.isDisplayable())     // just in case user killed OrtView window
		{   imgFrameLocation = imgFrame.getLocation();
			imgFrame.dispose();
		}

		// these variables need to be updated here since their dimension has changed...
		pixTx = new int[w * h];
        pixCr = new int[w * zCorr];
        pixSg = new int[h * zCorr];
        pixVol = new int[(zCorr + w)*(zCorr + h)];  // w*h to hold the tx img, + an offset zCorr for the cr cut at the top & the sg left/right

	    // update crosshair location (center crosshair)
	    wCurr = w/2;
	    hCurr = h/2;
	    zCurr = zCorr/2;

		Reslice();
	    createFrame();

    }




   // --------------------------------------------------
   // Action to perform when user calls Menu Process -> Reset
   // resets the views to what they looked like when OrtView was
   // initially started

    private void actionReset()
    {
        if (IJ.debugMode)
            IJ.write("\nDEBUG OrtView > actionReset()");

		if (!checkImgOrig())
        {
			IJ.error ("WARNING: Original image has changed! Retrieving new settings...");
			// retrieve and update some settings
            if (imgOrig.getStackSize()<2)
            {   IJ.error("Stack required");
                return;
            }
        }
	    w = wOrig;
	    h = hOrig;
	    z = zOrig;

		wCurr = w/2;
        hCurr = h/2;
        zCurr = imgOrig.getCurrentSlice();
		zCorr = 0;  // signals initialization and will be checked from within computeImg3DLinearly()
        cModel = imgOrig.getProcessor().getColorModel();

		// reset rotation related parameters
		rotationAngleW = 0;
		rotationAngleH = 0;
		rotationAngleZ = 0;
		rotationSequence = 0;
		imgRotated = false;
		img3DUnrotated = null;
		imgFrame.menuBar.menuItemUndoRotate.setEnabled(imgRotated);

        // voxel dimension and interpolation settings
        voxel_xDim = imgOrig.getCalibration().pixelWidth; // assumed the same as voxel_yDim
        voxel_zDim = imgOrig.getCalibration().pixelDepth; // these values are set to 1 by default by ImageJ if nothing else is specified
		zSpacing = 1;
		if (((voxel_zDim != 1.0) && (voxel_xDim != 1.0))  // pixel dimensions are not default ones, but specifically set
		   && (voxel_zDim != 0) && (voxel_xDim != 0))     // neither null
	    {   interpType = 1;                               // cubic spline
		    // set zSpacing for initial linear interpolation to reflect pixel proportions
		    zSpacing = Math.max (1, (int)Math.round((double)voxel_zDim / voxel_xDim));
		}
        else interpType = 0;                              // linear

        // compute the 3D matrix and the three sections
		// here "old" views are also disposed
	    computeImg3DLinearly();                // linear axial interpolation (interpType==0)
	    finishingInterpFlag = false;           // unlock crosshair-moving capability
										       // (see methods mouseReleased() and computeImg3D*())
		// vert Orientation remains as set by user, w/out being set back to the default (i.e. nucl.med.)
		if (vertOrientationChoice == 1)  // if it had been changed to radiology, update zCurr
			  zCurr = zCorr - zCurr + 1;     // + 1 bc zCurr starts from 1 rather than from 0
        Reslice();

        // preparing the output
		createFrame();


    } // actionReset()




   // --------------------------------------------------
   // Action to perform when user calls Menu Options -> Vertical Orientation
   // here, zCurr is updated and the image volume is inverted

    private void actionVertOrientation()
    {   int img3DLocal[][][] = new int[w][h][zCorr];

		if (IJ.debugMode)
		   IJ.write ("DEBUG OrtView > actionVertOrientation()");

		// update zCurr
		zCurr = zCorr - zCurr + 1;  // + 1 bc zCurr starts from 1 rather than from 0

		// invert image
		for (int iii = 0; iii < w; ++iii)
            for (int jjj = 0; jjj < h; ++jjj)
                for (int qqq = 0; qqq<zCorr; ++qqq)
                    img3DLocal[iii][jjj][qqq] = img3D[iii][jjj][zCorr - qqq -1];
		img3D = img3DLocal;

    }







   // --------------------------------------------------
   // Action to perform when user calls Menu Options -> Volume View

    private void actionVolumeView()
    {
            ImagePlus volViewImg;

            if (IJ.debugMode)
                IJ.write("DEBUG OrtView > enableVolumeView()  img dim= "+(w+zCorr)+"x"+(h+zCorr));
            if (imgTypeShort)       // Short image
                volViewImg = NewImage.createShortImage("Volume View ("+wCurr+","+hCurr+","+zCurr+")",w+zCorr,h+zCorr,1,NewImage.FILL_RAMP);
            else                    // Byte image
                volViewImg = NewImage.createByteImage("Volume View ("+wCurr+","+hCurr+","+zCurr+")",w+zCorr,h+zCorr,1,NewImage.FILL_RAMP);
            volViewImg.show();
            ImageProcessor volViewIP = volViewImg.getProcessor();
            int aux=0;
            for (int j=0; j<h+zCorr; j++)
                for (int i=0; i<w+zCorr; i++)
                    volViewIP.putPixel(i, j, pixVol[aux++] );
            //volViewIP.setPixels(pixVol);
            volViewIP.setColorModel(cModel);
            volViewIP.resetMinAndMax();
            volViewImg.updateAndDraw();
    }




   // --------------------------------------------------
   // Action to perform when user calls Menu Options -> Auto Adjust Brightness & Contrast...

    private void actionAutoAdjustBC()
	{
        // first compute min and max from original image
		// this code section is extracted from method autoAdjust(), class ContrastAdjuster.
		// However, since getStatistics() only considers the currently displayed
		// slice of a stack, auto adjust results would slightly vary depending
		// on the currently visualized stack slice of the original image.
		// Hence I embed the autoAdjust() code into a loop over all planes,
		// compute min and max over each single plane, and finally take the mean
		// of all "meaningful" (i.e. hmax>hmin) values

		double minAverage=0, min[] = new double [z];
		double maxAverage=0, max[] = new double [z];
        int autoThreshold = 5000;
		int iiTot=0;
		ImageStack imgOrigStack = imgOrig.getStack();
		ImagePlus ipCurr;

		for (int ii=0; ii<z; ii++)
		{
			ipCurr = new ImagePlus ("temp", imgOrigStack.getProcessor(ii+1));
            Calibration cal = ipCurr.getCalibration();
			ipCurr.setCalibration(null);
            ImageStatistics stats = ipCurr.getStatistics(); // get uncalibrated stats
			ipCurr.setCalibration(cal);
            int[] histogram = stats.histogram;
            int threshold = stats.pixelCount/autoThreshold;
            int i = -1;
            boolean found = false;
            do {
			    i++;
                found = histogram[i] > threshold;
               } while (!found && i<255);
            int hmin = i;
            i = 256;
            do {
               i--;
               found = histogram[i] > threshold;
            } while (!found && i>0);
            int hmax = i;
            if (hmax>hmin) {
               min[ii] = stats.histMin+hmin*stats.binSize;
               max[ii] = stats.histMin+hmax*stats.binSize;
			   iiTot++;
            }
		}

		if (iiTot==0) // just squeeze all values into [imgMin , imgMax]
		{
			if (IJ.debugMode)
               IJ.write ("DEBUG OrtViewMenu > No B&C to adjust");
			handleShort();
			return;
		}

		for (int j=0; j<iiTot; j++)
		{   minAverage += min[j];
			maxAverage += max[j];
		}
		minAverage /= iiTot;
		maxAverage /= iiTot;

		// now rescale pixel values
        float a=255/(float)(maxAverage-minAverage);
        float b=-a*(float)minAverage;
        for (int iii = 0; iii < w; ++iii)
            for (int jjj = 0; jjj < h; ++jjj)
                for (int qqq = 0; qqq<zCorr; ++qqq)
                {   img3D[iii][jjj][qqq] = Math.round(img3D[iii][jjj][qqq] * a + b);
                    if (img3D[iii][jjj][qqq] > 255) img3D[iii][jjj][qqq]=255;
                    if (img3D[iii][jjj][qqq] < 0) img3D[iii][jjj][qqq]=0;
                }



	}






// ===========================================================
// -----------------------------------------------------------

// Innter Class OrtViewInterpolation
// handles the Interpolation

// Why RUNNING INTERPOLATION IN A SEPARATE THREAD?
// In a previous version of the plugin, interpolation was performed by recursively
// calling method run(). In such way, however, it was not possible to
// cancel the execution of the interpolation method and leave the image as it
// already was - important feature, since computation of
// polynomial and cubic spline interpolation may require several mintues.
// Also, since interpolation takes up the entire processing power, there's no
// time left to update Java's ProgressMonitor nor ImageJ's ProgressBar

// Why INNER CLASS?
// The class is declared inner
// since it needs to have access to several objects and methods of the
// wrapping main OrtView_ class.
// It can not be "merged" with OrtView_ into a single class, because
// there already is a method OrtView_.run() (even though it has a different
// signature, I prefer to keep things clean and isolate OrtViewInterpolation
// with the rest of the OrtView_ code that has a different semantic.

// What CAN BE PERFORMED WHILE THIS THREAD IS RUNNING?
// Most menus of the OrtView window are disabled in order to preserve data
// integrity. Interaction with the crosshair pointer on the three
// volume cuts is fully enabled.

class OrtViewInterpolation implements Runnable
{

	OrtViewInterpSettings dlg;

	public void run ()
	{
		// backup values
		double voxel_xDimBackup, voxel_zDimBackup;
		int interpTypeBackup, zSpacingBackup;

		if (IJ.debugMode)
		{  IJ.write ("DEBUG OrtViewInterpolation > run()");
		   IJ.write("\nDEBUG Interp. Thread:\nDEBUG    Name = "+Thread.currentThread().getName());
		   IJ.write("DEBUG    Priority = "+Thread.currentThread().getPriority());
		   IJ.write("DEBUG    Group Name = "+Thread.currentThread().getThreadGroup().getName());
		   IJ.write("DEBUG    Active Count = "+Thread.currentThread().activeCount());
		}


		// disable (most) menus
		enableMenus (false);




		// if no changes were made then return
		if ((dlg.interpType == interpType) &&
		   ( ((dlg.interpType == 0) && (zSpacing == -dlg.zSpacing)) || // linear case
		   ( (dlg.interpType != 0) &&  // spline or polyn
		   (voxel_xDim == dlg.voxel_xDim) && (voxel_zDim == dlg.voxel_zDim))))
		   {    if (IJ.debugMode)
		            IJ.write ("DEBUG OrtViewInterpolation > exiting with unchanged interpolation values ");
				enableMenus(true);
				computingInterpolationFlag = false;
	            return;
		   }


		if (IJ.debugMode)
		{   if (dlg.interpType == 0) // linear
			   IJ.write ("DEBUG OrtViewInterpolation > New linear interpolation settings: zSpacing = "+-dlg.zSpacing);
			else IJ.write ("DEBUG OrtViewInterpolation > New interpolation settings: voxel dimension = ("+dlg.voxel_xDim+", "+dlg.voxel_xDim+", "+dlg.voxel_zDim+")");
		}


		// update values
		// first backup current values in case user cancels operation
		interpTypeBackup = interpType;
		zSpacingBackup = zSpacing;
		voxel_xDimBackup = voxel_xDim;
		voxel_zDimBackup = voxel_zDim;
		// retrieve new values;
        interpType = dlg.interpType;
		if (dlg.interpType == 0) // linear
		   zSpacing = -(dlg.zSpacing);
		else                    // spline or polyn
		{   voxel_xDim = dlg.voxel_xDim;
			voxel_zDim = dlg.voxel_zDim;
		}


		// interpolate
		if (interpType==1)
		{   if (!computeImg3DSpline())
		   {    // user aborted interpolation by pressing Cancel
				// return to backup values and stop thread execution
			    interpType = interpTypeBackup;
			    zSpacing = zSpacingBackup;
			    voxel_xDim = voxel_xDimBackup;
			    voxel_zDim = voxel_zDimBackup;
				generalFlag = -1; // flags to openConf and plugin-run that thread exits abnormally
				enableMenus(true);
		        computingInterpolationFlag = false;
 				return;
			}
		}
		else if (interpType==0) computeImg3DLinearly();
		else if (!computeImg3DPolyn())
		{   // user stopped interpolation by pressing Cancel
			// return to backup values and end thread execution
			interpType = interpTypeBackup;
			zSpacing = zSpacingBackup;
			voxel_xDim = voxel_xDimBackup;
			voxel_zDim = voxel_zDimBackup;
			generalFlag = -1; // flags to openConf and plugin-run that thread exits abnormally
			enableMenus(true);
		    computingInterpolationFlag = false;
 			return;
		}
		// "old" imgFrame is disposed at the end of interpolation, in order to avoid
		// collisions in case the user interacts on the image (interp.thread and
		// "parent" thread would be simultaneously accessing global variables)

		Reslice();




        // arrange the three views into a frame
        if (IJ.debugMode)
        {   IJ.write("DEBUG OrtViewInterpolation > run(): arranging views in new output frame");
            IJ.write("DEBUG OrtViewInterpolation > run(): new dimensions w="+w+" h="+h+" zCorr="+zCorr);
        }

	    createFrame();

		// reset rotation related parameters
		rotationAngleW = 0;
		rotationAngleH = 0;
		rotationAngleZ = 0;
		imgRotated = false;
		imgFrame.menuBar.menuItemUndoRotate.setEnabled(imgRotated);

	    // see comments at mouseReleased(...) method.
	    finishingInterpFlag = false;
		computingInterpolationFlag = false;




	} // end of method run()





	private void enableMenus (boolean state)
	{   imgFrame.menuBar.menuItemOpen.setEnabled(state);
		imgFrame.menuBar.menuItemSave.setEnabled(state);
		imgFrame.menuBar.menuExport.setEnabled(state);
		imgFrame.menuBar.menuItemQuitOrtview.setEnabled(state);
		imgFrame.menuBar.menuProcess.setEnabled(state);
		imgFrame.menuBar.menuOptions.setEnabled(state);
	}

} // end of inner class OrtViewInterpolation









// ===========================================================
// -----------------------------------------------------------

// Innter Class OrtViewRotation
// handles the Rotation

// For comments on the implementative choices (such as
// Why RUNNING INTERPOLATION IN A SEPARATE THREAD
// Why INNER CLASS
// What CAN BE PERFORMED WHILE THIS THREAD IS RUNNING )
// please refer to comments of Inner Class OrtViewInterpolation



class OrtViewRotation implements Runnable
{

	OrtViewRotationSettings dlg;

	public void run ()
	{
		// backup values
        int rotationSequenceBackup;
        int rotationAngleWBackup, rotationAngleHBackup, rotationAngleZBackup;

		if (IJ.debugMode)
		{  IJ.write ("DEBUG OrtViewRotation > run()");
		   IJ.write("\nDEBUG Rotation Thread:\nDEBUG    Name = "+Thread.currentThread().getName());
		   IJ.write("DEBUG    Priority = "+Thread.currentThread().getPriority());
		   IJ.write("DEBUG    Group Name = "+Thread.currentThread().getThreadGroup().getName());
		   IJ.write("DEBUG    Active Count = "+Thread.currentThread().activeCount());
		}


		// disable (most) menus
		enableMenus (false);




		// if no changes were made then return
		if ((dlg.rotationSequence == rotationSequence) &&
		   (dlg.rotationAngleH==rotationAngleH) && (-dlg.rotationAngleW==rotationAngleW)
		   && (dlg.rotationAngleZ==rotationAngleZ))
		   {    if (IJ.debugMode)
		            IJ.write ("DEBUG OrtViewRotation > exiting with unchanged rotation values ");
				enableMenus(true);
				computingRotationFlag = false;
	            return;
		   }




		// update values
		// first backup current values in case user cancels operation
		rotationSequenceBackup = rotationSequence;
		rotationAngleWBackup = rotationAngleW;
		rotationAngleHBackup = rotationAngleH;
		rotationAngleZBackup = rotationAngleZ;
		// retrieve new values;
		rotationSequence = dlg.rotationSequence;
		rotationAngleW = -dlg.rotationAngleW;
		rotationAngleH = dlg.rotationAngleH;
		rotationAngleZ = dlg.rotationAngleZ;



		if (!rotate3D())
		{   // user stopped rotation by pressing Cancel
			// return to backup values and end thread execution
		    rotationSequence = rotationSequenceBackup;
		    rotationAngleW = rotationAngleWBackup;
		    rotationAngleH = rotationAngleHBackup;
		    rotationAngleZ = rotationAngleZBackup;
			generalFlag = -1; // flags to openConf and plugin-run that thread exits abnormally
			enableMenus(true);
		    computingRotationFlag = false;
 			return;
		}
		// "old" imgFrame is disposed at the end of interpolation, in order to avoid
		// collisions in case the user interacts on the image (interp.thread and
		// "parent" thread would be simultaneously accessing global variables)

		Reslice();


        // arrange the three views into a frame
        if (IJ.debugMode)
        {   IJ.write("DEBUG OrtViewRotation > run(): arranging views in new output frame");
            IJ.write("DEBUG OrtViewRotation > run(): new dimensions w="+w+" h="+h+" zCorr="+zCorr);
        }

	    createFrame();
		imgFrame.menuBar.menuItemUndoRotate.setEnabled(true); // imgRotated was set to true in rotate3D()
	    // see comments at mouseReleased(...) method.
	    finishingRotationFlag = false;
		computingRotationFlag = false;




	} // end of method run()





	private void enableMenus (boolean state)
	{   imgFrame.menuBar.menuItemOpen.setEnabled(state);
		imgFrame.menuBar.menuItemSave.setEnabled(state);
		imgFrame.menuBar.menuExport.setEnabled(state);
		imgFrame.menuBar.menuItemQuitOrtview.setEnabled(state);
		imgFrame.menuBar.menuProcess.setEnabled(state);
		imgFrame.menuBar.menuOptions.setEnabled(state);
	}

} // end of inner class OrtViewRotation












} // end of main class OrtView_












// ===========================================================
// -----------------------------------------------------------

// Class OrtViewFrame
// handles the main frame of the gui to display the image

class OrtViewFrame extends JFrame {
    JPanel mainPanel;
    OrtViewPanel panTx, panCr, panSg;
    OrtViewMenu menuBar;
    Image imgTx, imgSg, imgCr;
    int w,h,zCorr;
    int vertOrientationChoice; // needed for the menu...
    final int border = 5;  // be wise and set me odd...




   // --------------------------------------------------
   // Construct the frame

   public OrtViewFrame(int w, int h, int zCorr, int vertOrientationChoice)
   {   enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        this.w = w;
        this.h = h;
        this.zCorr = zCorr;
        this.vertOrientationChoice = vertOrientationChoice;
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
     }






   // --------------------------------------------------
   // Component initialization

    private void jbInit() throws Exception
    {
        Border mainBorder, borderTransaxial, borderCoronal, borderSagittal;
        GridBagLayout gridBagLayout1 = new GridBagLayout();
        int border2 = border * 2 + 1; // space to leave out at the left & at the right for the vertical borders
        int border3 = border * 5 + 3; // space to leave out at top & botton for the horizontal borders


        // main panel
        //setIconImage(Toolkit.getDefaultToolkit().createImage(OrtViewFrame.class.getResource("gsgraph.ico")));
		if (IJ.debugMode)
         IJ.write("DEBUG OrtViewFrame > jbInit(): set up main panels");
        mainPanel = (JPanel) this.getContentPane();
        mainPanel.setLayout(gridBagLayout1);
        this.setTitle("OrtView Plugin");
        mainBorder = BorderFactory.createBevelBorder(BevelBorder.LOWERED,Color.white,Color.white,new Color(93, 93, 93),new Color(134, 134, 134));
        mainPanel.setBorder(mainBorder);



        // transaxial panel
        borderTransaxial = new TitledBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED,Color.white,Color.white,new Color(134, 134, 134),new Color(93, 93, 93)),"Transaxial", TitledBorder.CENTER, TitledBorder.ABOVE_TOP);
        panTx = new OrtViewPanel(w, h, "Transaxial");
        panTx.setBorder(borderTransaxial);
        panTx.setMinimumSize(new Dimension(w+border2,h+border3));
        panTx.setPreferredSize(new Dimension(w+border2,h+border3));
        panTx.addMouseListener(new java.awt.event.MouseAdapter()
        {   public void mouseReleased(MouseEvent e)
            {   panTx_mouseReleased(e);
            }
            public void mousePressed(MouseEvent e)
            {   panTx_mousePressed(e);
            }
         });
        panTx.addMouseMotionListener(new java.awt.event.MouseMotionAdapter()
        {   public void mouseMoved(MouseEvent e)
            {   panTx.setToolTipText("("+(e.getX()-panTx.x_offs+1)+", "+(e.getY()-panTx.y_offs+1)+")");
            }
        });
        panTx.setToolTipText(""); // needed to initialize the ToolTip!
        mainPanel.add(panTx, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(15,15,0,15), 0, 0));



        // coronal panel
        borderCoronal = new TitledBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED,Color.white,Color.white,new Color(93, 93, 93),new Color(134, 134, 134)),"Coronal", TitledBorder.CENTER, TitledBorder.BELOW_BOTTOM);
        panCr = new OrtViewPanel(w, zCorr, "Coronal");
        panCr.setBorder(borderCoronal);
        panCr.setMinimumSize(new Dimension(w+border2,zCorr+border3));
        panCr.setPreferredSize(new Dimension(w+border2,zCorr+border3));
        panCr.addMouseListener(new java.awt.event.MouseAdapter()
        {  public void mouseReleased(MouseEvent e)
            {   panCr_mouseReleased(e);
            }
            public void mousePressed(MouseEvent e)
            {   panCr_mousePressed(e);
            }
        });
        panCr.addMouseMotionListener(new java.awt.event.MouseMotionAdapter()
        {   public void mouseMoved(MouseEvent e)
            {   panCr.setToolTipText("("+(e.getX()-panCr.x_offs+1)+", "+(e.getY()-panCr.y_offs+1)+")");
            }
        });
        panCr.setToolTipText(""); // needed to initialize the ToolTip!
        mainPanel.add(panCr,  new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(0,15,15,0), 0,0));



        // sagittal panel
        borderSagittal = new TitledBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED,Color.white,Color.white,new Color(134, 134, 134),new Color(93, 93, 93)),"Sagittal", TitledBorder.CENTER, TitledBorder.BELOW_BOTTOM);
        panSg = new OrtViewPanel(h, zCorr, "Sagittal");
        panSg.setBorder(borderSagittal);
        panSg.setMinimumSize(new Dimension(h+border2,zCorr+border3));
        panSg.setPreferredSize(new Dimension(h+border2,zCorr+border3));
        panSg.addMouseListener(new java.awt.event.MouseAdapter()
        {   public void mouseReleased(MouseEvent e)
            {   panSg_mouseReleased(e);
            }
            public void mousePressed(MouseEvent e)
            {   panSg_mousePressed(e);
            }
        });
        panSg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter()
        {   public void mouseMoved(MouseEvent e)
            {   panSg.setToolTipText("("+(e.getX()-panSg.x_offs+1)+", "+(e.getY()-panSg.y_offs+1)+")");
            }
        });
        panCr.setToolTipText(""); // needed to initialize the ToolTip!
        mainPanel.add(panSg,  new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.SOUTHEAST, GridBagConstraints.NONE, new Insets(0,0,15,15), 0,0));



        // Menu Bar
        menuBar = new OrtViewMenu(this, vertOrientationChoice);
        setJMenuBar(menuBar);



		if (IJ.debugMode)
         IJ.write("DEBUG OrtViewFrame > jbInit() done");

    }






   // --------------------------------------------------
   // set some values (once and for all), create three images and display them

   public void createImages (int pixTx[], int pixCr[], int pixSg[], ColorModel cModel)
   {
        if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > createImages()");

        // transaxial image
        panTx.x_offs = border;
        panTx.y_offs = border*4+3;
        panTx.cModel = cModel;
        panTx.colorX = Color.blue;
        panTx.colorY = Color.green;
        panTx.createImage(pixTx);


        // coronal image
        panCr.x_offs = border;
        panCr.y_offs = border;
        panCr.cModel = cModel;
        panCr.colorX = Color.red;
        panCr.colorY = Color.green;
        panCr.createImage(pixCr);


        // sagittal image
        panSg.x_offs = border;
        panSg.y_offs = border;
        panSg.cModel = cModel;
        panSg.colorX = Color.red;
        panSg.colorY = Color.blue;
        panSg.createImage(pixSg);
    }





   // --------------------------------------------------
   // recompute three images (by recreating them) and display them

   public void computeImages (int pixTx[], int pixCr[], int pixSg[])
   {
        if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > computeImages()");

        // simply call the createImage function
        panTx.createImage(pixTx);
        panCr.createImage(pixCr);
        panSg.createImage(pixSg);
    }





   // --------------------------------------------------
   // display the three sections

   public void showImages ()
   {
        if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > showImages()");
        panTx.showImage();
        panCr.showImage();
        panSg.showImage();
    }





   // --------------------------------------------------
   // set the crosshair coordinates
   // this function is also used at the very beginning in order to avoid that
   // junky crosshairs are plot by an implicit, premature call to paint()

   public void setCrosshairs (int wCurr, int hCurr, int zCurr)
   {
        panTx.x_crss = wCurr+panTx.x_offs-1;
        panTx.y_crss = hCurr+panTx.y_offs-1;
        panCr.x_crss = wCurr+panCr.x_offs-1;
        panCr.y_crss = zCurr+panCr.y_offs-1;
        panSg.x_crss = hCurr+panSg.x_offs-1;
        panSg.y_crss = zCurr+panSg.y_offs-1;

        if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > setCrosshairs("+panTx.x_crss+", "+panTx.y_crss+", "+panCr.y_crss+")");
    }




   // --------------------------------------------------
   // draws the three crosshair cursors

   public void drawCrosshairs ()
   {
        if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > drawCrosshairs()");

        panTx.drawCrosshair();
        panCr.drawCrosshair();
        panSg.drawCrosshair();
    }





   // --------------------------------------------------
   // Overridden so we can exit when window is closed

    protected void processWindowEvent(WindowEvent e)
    {   super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING)
        {   this.dispose();
            System.gc();
            IJ.write("\n\nOrtView Killed\n========================================\n");
            return;
        }
    }





    // ----------------------------------------------------
    // mouse functions

    void panTx_mouseReleased(MouseEvent e)
    {
    	// before passing on the getXY values check that the mouse was released on the image
        int x = e.getX();
        int y = e.getY();
        if (x < panTx.x_offs)
            x = panTx.x_offs;
        else if (x >= panTx.x_offs + w)
            x = panTx.x_offs + w - 1;
        if (y < panTx.y_offs)
            y = panTx.y_offs;
        else if (y >= panTx.y_offs + h)
            y = panTx.y_offs + h - 1;

        panTx.x_crss = x;
		panTx.y_crss = y;
        panCr.x_crss = x;
        panSg.x_crss = y-panTx.y_offs+panSg.x_offs;
		if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > panTx_mouseReleased: "+panTx.x_crss+","+panTx.y_crss);
    }
    void panTx_mousePressed(MouseEvent e)
    {
    	// before passing on the getXY values check that the mouse was pressed on the image
        int x = e.getX();
        int y = e.getY();
        if (x < panTx.x_offs)
            x = panTx.x_offs;
        else if (x >= panTx.x_offs + w)
            x = panTx.x_offs + w - 1;
        if (y < panTx.y_offs)
            y = panTx.y_offs;
        else if (y >= panTx.y_offs + h)
            y = panTx.y_offs + h - 1;

    	panTx.x_crss = e.getX();
		panTx.y_crss = e.getY();
        panCr.x_crss = e.getX();
        panSg.x_crss = e.getY()-panTx.y_offs+panSg.x_offs;
		if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > panTx_mousePressed: "+panTx.x_crss+","+panTx.y_crss);
    }




    void panCr_mouseReleased(MouseEvent e)
    {
    	// before passing on the getXY values check that the mouse was released on the image
        int x = e.getX();
        int y = e.getY();
        if (x < panCr.x_offs)
            x = panCr.x_offs;
        else if (x >= panCr.x_offs + w)
            x = panCr.x_offs + w - 1;
        if (y < panCr.y_offs)
            y = panCr.y_offs;
        else if (y >= panCr.y_offs + zCorr)
            y = panCr.y_offs + zCorr - 1;

    	panCr.x_crss = x;
		panCr.y_crss = y;
        panTx.x_crss = x;
        panSg.y_crss = y;
		if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > panCr_mouseReleased: "+panCr.x_crss+","+panCr.y_crss);
    }
    void panCr_mousePressed(MouseEvent e)
    {
    	// before passing on the getXY values check that the mouse was pressed on the image
        int x = e.getX();
        int y = e.getY();
        if (x < panCr.x_offs)
            x = panCr.x_offs;
        else if (x >= panCr.x_offs + w)
            x = panCr.x_offs + w - 1;
        if (y < panCr.y_offs)
            y = panCr.y_offs;
        else if (y >= panCr.y_offs + zCorr)
            y = panCr.y_offs + zCorr - 1;

    	panCr.x_crss = x;
		panCr.y_crss = y;
        panTx.x_crss = x;
        panSg.y_crss = y;
		if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > panCr_mousePressed: "+panCr.x_crss+","+panCr.y_crss);
    }
    void panSg_mouseReleased(MouseEvent e)
    {
    	// before passing on the getXY values check that the mouse was released on the image
        int x = e.getX();
        int y = e.getY();
        if (x < panSg.x_offs)
            x = panSg.x_offs;
        else if (x >= panSg.x_offs + h)
            x = panSg.x_offs + h - 1;
        if (y < panSg.y_offs)
            y = panSg.y_offs;
        else if (y >= panSg.y_offs + zCorr)
            y = panSg.y_offs + zCorr - 1;

    	panSg.x_crss = x;
		panSg.y_crss = y;
        panCr.y_crss = y;
        panTx.y_crss = x-panSg.x_offs+panTx.y_offs;
		if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > panTx_mouseReleased: "+panSg.x_crss+","+panSg.y_crss);
    }
    void panSg_mousePressed(MouseEvent e)
    {
    	// before passing on the getXY values check that the mouse was pressed on the image
        int x = e.getX();
        int y = e.getY();
        if (x < panSg.x_offs)
            x = panSg.x_offs;
        else if (x >= panSg.x_offs + h)
            x = panSg.x_offs + h - 1;
        if (y < panSg.y_offs)
            y = panSg.y_offs;
        else if (y >= panSg.y_offs + zCorr)
            y = panSg.y_offs + zCorr - 1;

    	panSg.x_crss = x;
		panSg.y_crss = y;
        panCr.y_crss = y;
        panTx.y_crss = x-panSg.x_offs+panTx.y_offs;
		if (IJ.debugMode)
            IJ.write("DEBUG OrtViewFrame > panTx_mousePressed: "+panSg.x_crss+","+panSg.y_crss);
    }





}







// ===========================================================
// -----------------------------------------------------------

// Class OrtViewPanel
// Handles the panel to display a single section of the 3D image

class OrtViewPanel extends JPanel {

    Image img;
    int w, h;               // image dimensions
    int x_offs, y_offs;     // image position inside the panel
    int x_crss, y_crss;     // mouse position
    ColorModel cModel;
    Color colorX, colorY;   // color of the crosshair
    String panelName;



    // constructor
    public OrtViewPanel (int w, int h, String pName)
    {
        this.w = w;
        this.h = h;
        this.cModel = cModel;
        this.panelName = new String(pName);
    }




    // override method createImage
    public void createImage (int pix[])
    {
        for (int i=0;i<w*h;i++)
            if (pix[i]>255) pix[i]=255;

        img = super.createImage(new MemoryImageSource(w, h, cModel, pix, 0, w));
        if (img == null)
            IJ.error("OrtViewPanel > createImage(): error creating "+ panelName +" image");
    }




    // displays the image
    public void showImage()
    {    // "this" is registered as an observer by passing it as last parameter to drawImage
         if (!this.getGraphics().drawImage(img, x_offs, y_offs, this))
            IJ.write("ERROR can not completely load "+ panelName +" image");
         else if (IJ.debugMode)
            IJ.write("DEBUG OrtViewPanel > showImage(): "+ panelName +" image fully loaded and displayed at ("+x_offs+", "+y_offs+")");
    }



    // override method paint
    public void paint(Graphics g)
    {
        try
        {   super.paint(g);
            g.drawImage(img, x_offs, y_offs, this);
            g.setColor(colorX);
            g.drawLine(0+x_offs, y_crss, w-1+x_offs, y_crss);
            g.setColor(colorY);
            g.drawLine(x_crss, 0+y_offs, x_crss, h-1+y_offs);
        }
        catch(java.lang.NullPointerException e) {   }
    }





    // override update() without calling clear():
    // this should reduce flicker...
    public void update (Graphics g)
    {   paint(g);
    }







   // draw the crosshair mouse
   // needs to redisplay the entire image, in order to delete the old crosshair!
   // However, this cannot be done simply by calling paint() bc paint() does not
   // work on the entire panel area, but only on a clipping area...
   public void drawCrosshair ()
   {
         if (IJ.debugMode)
            IJ.write("DEBUG OrtViewPanel > drawCrosshair("+x_crss+", "+y_crss+") on "+ panelName +" image");
         Graphics g = this.getGraphics();
         g.drawImage(img, x_offs, y_offs, this); // cover up old crosshair
         g.setColor(colorX);
         g.drawLine(0+x_offs, y_crss, w-1+x_offs, y_crss);
         g.setColor(colorY);
         g.drawLine(x_crss, 0+y_offs, x_crss, h-1+y_offs);
    }


}












// ===========================================================
// -----------------------------------------------------------

// Class OrtViewMenu
// Menu of the Frame

class OrtViewMenu extends JMenuBar {


    // Menus and menu items
    JFrame parentFrame;
    JMenu menuFile = new JMenu();                 // File
    JMenuItem menuItemOpen = new JMenuItem();
    JMenuItem menuItemSave = new JMenuItem();
    JMenu menuExport = new JMenu();
    JMenuItem menuItemExpTxImg = new JMenuItem();
    JMenuItem menuItemExpCrImg = new JMenuItem();
    JMenuItem menuItemExpSgImg = new JMenuItem();
    JMenuItem menuItemExp3Img = new JMenuItem();
    JMenuItem menuItemExpTxStk = new JMenuItem();
    JMenuItem menuItemExpCrStk = new JMenuItem();
    JMenuItem menuItemExpSgStk = new JMenuItem();
    JMenuItem menuItemExp3Stk = new JMenuItem();
    JMenuItem menuItemQuitOrtview = new JMenuItem();
    JMenuItem menuItemQuitIJ = new JMenuItem();
    JMenu menuProcess = new JMenu();              // Process
    JMenuItem menuItemInterpolate = new JMenuItem();
    JMenu menuSmooth = new JMenu();
    JMenuItem menuItemSmooth3 = new JMenuItem();
    JMenuItem menuItemSmooth8 = new JMenuItem();
    JMenuItem menuItemSmooth27 = new JMenuItem();
	JMenuItem menuItemRotate = new JMenuItem();
	JMenuItem menuItemUndoRotate = new JMenuItem();
	JMenuItem menuItemReset = new JMenuItem();
    JMenu menuOptions = new JMenu();              // Options
    JMenu menuOrientation = new JMenu();
    JRadioButtonMenuItem menuItemNuclMed = new JRadioButtonMenuItem();
    JRadioButtonMenuItem menuItemRadiology = new JRadioButtonMenuItem();
    JMenuItem menuItemVolView = new JMenuItem();
    JMenuItem menuItemCrosshair = new JMenuItem();
	JMenuItem menuItemAdjustBC = new JMenuItem();
    JMenu menuHelp = new JMenu();                 // Help
	JMenuItem menuItemReadMe = new JMenuItem();
    JMenuItem menuItemAbout = new JMenuItem();

    // other variables
    int vertOrientationChoice;  // 0=Nuclear Medicine;   1=Radiology



   // constructor
    public OrtViewMenu (JFrame parentFrame, int vertOrientationChoice)
    {
        this.parentFrame = parentFrame;
        this.vertOrientationChoice = vertOrientationChoice;

        // define submenus and menu items
        menuFile.setText("File");                              // File
        menuItemOpen.setText("Open Configuration...");
        menuItemSave.setText("Save Configuration...");
        menuExport.setText("Export images");
        menuItemExpTxImg.setText("Export Transaxial Image");
        menuItemExpCrImg.setText("Export Coronal Image");
        menuItemExpSgImg.setText("Export Sagittal Image");
        menuItemExp3Img.setText("Export all 3 Images");
        menuItemExpTxStk.setText("Export Transaxial Stack");
        menuItemExpCrStk.setText("Export Coronal Stack");
        menuItemExpSgStk.setText("Export Sagittal Stack");
        menuItemExp3Stk.setText("Export all 3 Stacks");
        menuItemQuitOrtview.setText("Quit OrtView");
        menuItemQuitIJ.setText("Quit ImageJ");
        menuProcess.setText("Process");                        // Process
        menuItemInterpolate.setText("Interpolate...");
        menuSmooth.setText("Smooth");
	    menuItemSmooth3.setText("axially, over 3 pixel");
	    menuItemSmooth8.setText("over a 2x2x2 neighbourhood");
	    menuItemSmooth27.setText("over a 3x3x3 neighbourhood");
        menuItemRotate.setText("Rotate...");
        menuItemUndoRotate.setText("Undo Rotation");
		menuItemReset.setText("Reset");
        menuOptions.setText("Options");                        // Options
        menuOrientation.setText("Orientation   ");
        menuItemNuclMed.setText("Nuclear Medicine");
        menuItemRadiology.setText("Radiology");
        ButtonGroup bg = new ButtonGroup();
        bg.add(menuItemNuclMed);
        bg.add(menuItemRadiology);
        switchVertOrientationChoice();
        menuItemVolView.setText("Volume View");
        menuItemCrosshair.setText("Set Crosshair...");
		menuItemAdjustBC.setText("Auto adjust Brightness/Contrast...");
        menuHelp.setText("Help");                              // Help
		menuItemReadMe.setText("OrtView \"Manual\"");
        menuItemAbout.setText("About...");


        // Put them all together into the menuBar
        add(menuFile);
        add(menuProcess);
        add(menuOptions);
        add(menuHelp);
        menuFile.add(menuItemOpen);
        menuFile.add(menuItemSave);
        menuFile.add(menuExport);
        menuFile.addSeparator();
        menuFile.add(menuItemQuitOrtview);
        menuFile.add(menuItemQuitIJ);
        menuProcess.add(menuItemInterpolate);
        menuProcess.add(menuSmooth);
        menuProcess.add(menuItemRotate);
        menuProcess.addSeparator();
        menuProcess.add(menuItemUndoRotate);
		menuItemUndoRotate.setEnabled(false);  // "unrotated" is not possible at plugin start
		menuProcess.add(menuItemReset);
        menuOptions.add(menuOrientation);
        menuOrientation.add(menuItemNuclMed);
        menuOrientation.add(menuItemRadiology);
        menuOptions.add(menuItemVolView);
        menuOptions.add(menuItemCrosshair);
		menuOptions.add(menuItemAdjustBC);
		menuHelp.add(menuItemReadMe);
        menuHelp.add(menuItemAbout);
        menuExport.add(menuItemExpTxImg);
        menuExport.add(menuItemExpCrImg);
        menuExport.add(menuItemExpSgImg);
        menuExport.add(menuItemExp3Img);
        menuExport.add(menuItemExpTxStk);
        menuExport.add(menuItemExpCrStk);
        menuExport.add(menuItemExpSgStk);
        menuExport.add(menuItemExp3Stk);
	    menuSmooth.add(menuItemSmooth3);
	    menuSmooth.add(menuItemSmooth8);
	    menuSmooth.add(menuItemSmooth27);



        // Define Actions
        menuItemQuitIJ.addActionListener(new java.awt.event.ActionListener()
        {   public void actionPerformed(ActionEvent e)      // File -> Quit ImageJ
            {   System.exit(0);
            }
        });
		menuItemReadMe.addActionListener(new ActionListener()
		{   public void actionPerformed (ActionEvent e)     // Help -> OrtView "Manual"
			{   String fs = System.getProperty("file.separator");   // file separator
				String uh = System.getProperty("user.dir");        // User's current working directory
				new TextWindow(uh+fs+"plugins"+fs+"Mednuc"+fs+"OrtViewHelp.txt", 500, 400);
				if (IJ.debugMode)
				   IJ.write ("DEBUG OrtViewMenu > OrtView \"Manual\" path = "+uh+fs+"plugins"+fs+"Mednuc"+fs+"OrtViewHelp.txt");
			}
		});
        menuItemAbout.addActionListener(new java.awt.event.ActionListener()
        {   public void actionPerformed(ActionEvent e)      // Help -> About
            {   menuItemAbout_actionPerformed(e);
            }
        });

    }




    // activate appropriate vertical Orientation Choice
    public void switchVertOrientationChoice()
    {
        if (vertOrientationChoice==0) // Nuclear Medicine
        {   menuItemNuclMed.setSelected(true);
            menuItemRadiology.setSelected(false);
        }
        else
        {   menuItemNuclMed.setSelected(false);
            menuItemRadiology.setSelected(true);
        }
    }





   // --------------------------------------------------
   // Help -> About

    public void menuItemAbout_actionPerformed(ActionEvent e)
    {   OrtViewAboutBox dlg = new OrtViewAboutBox(parentFrame);
        Dimension dlgSize = dlg.getPreferredSize();
        Dimension frmSize = parentFrame.getSize();
        Point loc = parentFrame.getLocation();
        dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
        dlg.setModal(true);
        dlg.show();
    }



}




// ===========================================================
// -----------------------------------------------------------

// Class OrtViewAboutBox
// Help -> About Dialog box

class OrtViewAboutBox extends JDialog implements ActionListener
{
    JButton buttonOK = new JButton();
    String product = "OrtView 1.0";
    String copyright = "Copyright MedNuc (c) 2002";
    String comments = "Send comments to bonetto@disi.unige.it";




   // --------------------------------------------------
   // Constructor

    public OrtViewAboutBox(Frame parent)
    {
        super(parent);
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        pack();
    }




    // --------------------------------------------------
    // Component initialization

    private void jbInit() throws Exception
    {
        // Text
        JPanel insetsPanelText = new JPanel();
        insetsPanelText.setLayout(new GridLayout(3,1));
        insetsPanelText.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        insetsPanelText.add(new Label(product, Label.CENTER), null);
        insetsPanelText.add(new Label(copyright, Label.CENTER), null);
        insetsPanelText.add(new Label(comments, Label.CENTER), null);

        // OK Botton
        buttonOK.setText("Ok");
        buttonOK.addActionListener(this);
        JPanel insetsPanelOK = new JPanel();
        insetsPanelOK.setLayout(new FlowLayout());
        insetsPanelOK.add(buttonOK, null);

        // Icon
/*        JLabel iconLabel = new JLabel();
        JPanel insetsPanelIcon = new JPanel();
        insetsPanelIcon.setLayout(new FlowLayout());
        insetsPanelIcon.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        insetsPanelIcon.add(iconLabel, null);

        // Icon goes left to Text in the upper half of the dialog box
        JPanel panelUp = new JPanel();
        panelUp.setLayout(new BorderLayout());
        panelUp.add(insetsPanelIcon, BorderLayout.WEST);
        panelUp.add(insetsPanelText, BorderLayout.CENTER);
*/
        // Put it all together into the main Panel
        //imageLabel.setIcon(new ImageIcon(Frame2_AboutBox.class.getResource("[Your Image]")));
        this.setTitle("About");
        setResizable(false);
        JPanel panelMain = new JPanel();
        panelMain.setLayout(new BorderLayout());
        panelMain.add(insetsPanelOK, BorderLayout.SOUTH);
//        panelMain.add(panelUp, BorderLayout.NORTH);
        panelMain.add(insetsPanelText, BorderLayout.NORTH);
        this.getContentPane().add(panelMain, null);
    }



   // --------------------------------------------------
   // Overridden so we can exit when window is closed

    protected void processWindowEvent(WindowEvent e)
    {   if (e.getID() == WindowEvent.WINDOW_CLOSING)
           dispose();
        super.processWindowEvent(e);
    }



   // --------------------------------------------------
   // Close the dialog on a button event

    public void actionPerformed(ActionEvent e)
    {   if (e.getSource() == buttonOK)
           dispose();
    }
}
















// ===========================================================
// -----------------------------------------------------------

// Class OrtViewInterpSettings
// Popup Frame to set the Interpolation parameters

class OrtViewInterpSettings extends JDialog implements ActionListener
{

    // radio buttons
    JPanel radioButtonPanel = new JPanel();
    JRadioButton linearButton = new JRadioButton();
    JRadioButton splineButton = new JRadioButton();
    JRadioButton polynomialButton = new JRadioButton();
    // zSpacing for linear iterpolation
    JPanel zSpacingPanel = new JPanel();
    JTextField zSpacingField = new JTextField();
    JLabel zSpacingLabel = new JLabel();
    // voxel dimension for spline and polynomial interpolation
    JPanel voxelDimPanel = new JPanel();
    JLabel voxelDimLabel = new JLabel();
    JTextField xValueField = new JTextField();
    JLabel xValueLabel = new JLabel();
    JTextField yValueField = new JTextField();
    JLabel yValueLabel = new JLabel();
    JTextField zValueField = new JTextField();
    JLabel zValueLabel = new JLabel();
    // OK and cancel Buttons
    JButton OKButton = new JButton("OK");
    JButton cancelButton = new JButton("Cancel");


    // other status variables
    int measurementUnit;        // 0=pixel, 1=mm
    int interpType;             // 0=linear, 1=spline, 2=polyn
    int zSpacing;
    double voxel_xDim, voxel_zDim;  // voxel_yDim is implicitly assumed to be equal to voxel_xDim



    /* Construct the frame */
    public OrtViewInterpSettings(int measurementUnit, int interpType, int zSpacing, double voxel_xDim, double voxel_zDim)
    {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        this.measurementUnit = measurementUnit;
        this.interpType = interpType;
        this.zSpacing = zSpacing;
        this.voxel_xDim = voxel_xDim;
        this.voxel_zDim = voxel_zDim;

        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        pack();
    }





    /* Component initialization */
    private void jbInit() throws Exception
    {
        // radio buttons
        // linear Button
        linearButton.setText("Linear");
        linearButton.addActionListener(this);
        // spline Button
        splineButton.setText("Cubic Spline");
        splineButton.addActionListener(this);
        // polynomial Button
        polynomialButton.setText("Polynomial");
        polynomialButton.addActionListener(this);
        // Group the three radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(linearButton);
        group.add(splineButton);
        group.add(polynomialButton);
        if (interpType == 0)
            linearButton.setSelected(true);
        else if (interpType == 1)
            splineButton.setSelected(true);
        else polynomialButton.setSelected(true);
        // RadioButton Panel
        GridLayout gridLayoutRadio = new GridLayout();
        gridLayoutRadio.setRows(3);
        gridLayoutRadio.setColumns(1);
        radioButtonPanel.setLayout(gridLayoutRadio);
        radioButtonPanel.add(linearButton, null);
        radioButtonPanel.add(splineButton, null);
        radioButtonPanel.add(polynomialButton, null);




        // zSpacing Panel for linear iterpolation
        // label
        zSpacingLabel.setText("Spacing between planes");
        // input field
        zSpacingField.setHorizontalAlignment(SwingConstants.RIGHT);
        zSpacingField.setMaximumSize(new Dimension(50, 18));
        zSpacingField.setMinimumSize(new Dimension(50, 18));
        zSpacingField.setPreferredSize(new Dimension(50, 18));
        zSpacingField.setMargin(new Insets(2, 2, 2, 2));
        zSpacingField.setText(String.valueOf(zSpacing));
        zSpacingField.addActionListener(this);
        // Panel
        zSpacingPanel.setLayout(new GridBagLayout());
        zSpacingPanel.add(zSpacingField, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), -20, 5));
        zSpacingPanel.add(zSpacingLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 11));



        // voxel dimension Panel for spline and polynomial interpolation
        // label
        voxelDimLabel.setHorizontalAlignment(SwingConstants.CENTER);
        voxelDimLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        voxelDimLabel.setVerticalAlignment(SwingConstants.BOTTOM);
        voxelDimLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
        if (measurementUnit==1)
            voxelDimLabel.setText("Voxel Dimension (mm)");
        else voxelDimLabel.setText("Voxel Dimension (pixel)");
        Dimension tmpDim = new Dimension (4,2);
        // x
        xValueField.setMaximumSize(tmpDim);
        xValueField.setMinimumSize(tmpDim);
        xValueField.setPreferredSize(tmpDim);
        xValueField.setText(String.valueOf(voxel_xDim));
        xValueField.setHorizontalAlignment(SwingConstants.RIGHT);
        xValueLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        xValueLabel.setText("x    ");
        xValueLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        xValueLabel.setVerticalAlignment(SwingConstants.TOP);
        // y
        yValueField.setMaximumSize(tmpDim);
        yValueField.setMinimumSize(tmpDim);
        yValueField.setPreferredSize(tmpDim);
        yValueField.setText(String.valueOf(voxel_xDim));
        yValueField.setHorizontalAlignment(SwingConstants.RIGHT);
        yValueLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        yValueLabel.setText("y");
        yValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        yValueLabel.setVerticalAlignment(SwingConstants.TOP);
        yValueField.setEnabled(false);  // always disabled, since voxel_yDim
        yValueLabel.setEnabled(false);  // is assumed equal to voxel_xDim
        // z
        zValueField.setMaximumSize(tmpDim);
        zValueField.setMinimumSize(tmpDim);
        zValueField.setPreferredSize(tmpDim);
        zValueField.setText(String.valueOf(voxel_zDim));
        zValueField.setHorizontalAlignment(SwingConstants.RIGHT);
        zValueLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        zValueLabel.setText("    z");
        zValueLabel.setHorizontalAlignment(SwingConstants.LEFT);
        zValueLabel.setVerticalAlignment(SwingConstants.TOP);
        // panel
        voxelDimPanel.setLayout(new GridBagLayout());
        voxelDimPanel.add(voxelDimLabel, new GridBagConstraints(0, 0, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        voxelDimPanel.add(xValueField, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        voxelDimPanel.add(xValueLabel, new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        voxelDimPanel.add(yValueField, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        voxelDimPanel.add(yValueLabel, new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        voxelDimPanel.add(zValueField, new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        voxelDimPanel.add(zValueLabel, new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));



        // enable / disable fields...
        switchInputFields();



        this.setTitle("Interpolation Settings");
        setResizable(false);
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new GridBagLayout());



        // main panel "Interpolation Settings"
        //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame2.class.getResource("[Your Icon]")));
        // radio buttons (left half of frame)
        contentPane.add(radioButtonPanel,new GridBagConstraints(0, 0, 1, 3, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 10, 10, 0), 0, 0));
        // zSpacing and voxel dimension (right half of frame)
        contentPane.add(zSpacingPanel, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.NORTH, GridBagConstraints.HORIZONTAL, new Insets(2, 0, 8, 20), 0, 8));
        contentPane.add(voxelDimPanel, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.NORTHEAST, GridBagConstraints.BOTH, new Insets(11, 0, 0, 15), 0, 0));
        // OK and Cancel buttons (bottom of frame)
        OKButton.addActionListener(this);
        cancelButton.addActionListener(this);
        contentPane.add(OKButton, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(19, 59, 18, 0), 0, 0));
        contentPane.add(cancelButton, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(19, 0, 18, 0), 0, 0));

		getRootPane().setDefaultButton(OKButton);
        this.getContentPane().add(contentPane, null);

    }



    // enable / disable input fields appropriately
    protected void switchInputFields()
    {
        if (interpType==0) // linear interpolation active
        {   zSpacingField.setEnabled(true);
            zSpacingLabel.setEnabled(true);
            voxelDimLabel.setEnabled(false);
            xValueField.setEnabled(false);
            xValueLabel.setEnabled(false);
            zValueField.setEnabled(false);
            zValueLabel.setEnabled(false);
        }
        else // spline or polynomial interpolation
        {   zSpacingField.setEnabled(false);
            zSpacingLabel.setEnabled(false);
            voxelDimLabel.setEnabled(true);
            xValueField.setEnabled(true);
            xValueLabel.setEnabled(true);
            zValueField.setEnabled(true);
            zValueLabel.setEnabled(true);
        }
    }




    /* Overridden so we can exit when window is closed */
    protected void processWindowEvent(WindowEvent e)
    {
        if (e.getID() == WindowEvent.WINDOW_CLOSING)
           dispose();
        super.processWindowEvent(e);
      /*super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING)
            jMenuFileExit_actionPerformed(null);*/
    }





    public void actionPerformed(ActionEvent e)
    {   if (e.getSource() == OKButton)
        {   // first check all user input!
            if (interpType == 0)
            {    if (!check_zSpacing())
                    return;
            }
            else
            {   if (!check_x() || !check_z())
                    return;
/*				if (voxel_xDim > voxel_zDim)
                {   IJ.error("ERROR x voxel dimension can not be larger than the z one!");
                    return;
                }
*/            }
            // set zSpacing to negative to flag that OK was pressed
            zSpacing *= -1;
            dispose();
        }
        else if (e.getSource() == cancelButton)
        {   // dispose without passing over any value
            dispose();
        }
        else if (e.getSource() == linearButton)
        {   interpType = 0;
            switchInputFields();
        }
        else if (e.getSource() == splineButton)
        {   interpType = 1;
            switchInputFields();
        }
        else if (e.getSource() == polynomialButton)
        {   interpType = 2;
            switchInputFields();
        }
        else if (e.getSource() == zSpacingField)
            check_zSpacing();
        else if (e.getSource() == xValueField)
            check_x();
        else if (e.getSource() == zValueField)
            check_z();
    }




    // spell checking of the zSpacingField input
    private boolean check_zSpacing()
    {   try
        {   Integer tmp = Integer.valueOf(zSpacingField.getText());
            if (tmp.intValue() <= 0)
            {   IJ.error("ERROR Spacing between planes must be a positive integer!");
                return(false);
            }
            else
            {   zSpacing = tmp.intValue();
                return(true);
            }
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR Spacing between planes must be an integer!");
            return(false);
        }
    }


    // spell checking of the xValueField input
    private boolean check_x()
    {   try
        {   Double tmp = Double.valueOf(xValueField.getText());
            if (tmp.doubleValue() <= 0)
            {   IJ.error("ERROR x voxel dimension must be positive!");
                return(false);
            }
            else
            {   voxel_xDim = tmp.doubleValue();
                yValueField.setText(String.valueOf(voxel_xDim));
                return(true);
            }
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR x voxel dimension must be a number!");
            return(false);
        }
    }


    // spell checking of the zValueField input
    private boolean check_z()
    {   try
        {   Double tmp = Double.valueOf(zValueField.getText());
            if (tmp.doubleValue() <= 0)
            {   IJ.error("ERROR z voxel dimension must be positive!");
                return(false);
            }
            else
            {   voxel_zDim = tmp.doubleValue();
                return(true);
            }
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR z voxel dimension must be a number!");
            return(false);
        }
    }




}







// ===========================================================
// -----------------------------------------------------------

// Class OrtViewRotationSettings
// pop up the interface to apply a rotation to the volume
// the interface is organized into 6 tabbed panes, each of which is related to a
// specific sequence of the three main axes around which the rotation has to be
// performed. In fact, a full 3D rotation is performed as a sequence of three
// rotations around the three main axes respectively.

class OrtViewRotationSettings extends JDialog implements ActionListener
{

	// status variables
	int rotationAngleW, rotationAngleH, rotationAngleZ;
	int rotationSequence;

    // Two buttons
    JButton jButtonOK = new JButton("OK");
    JButton jButtonCancel = new JButton("Cancel");
    // "angles" section
	JTabbedPane anglesTPane = new JTabbedPane();
    JPanel anglesPanels[] = new JPanel[6]; // 0=xyz 1=xzy 2=yxz 3=yzx 4=zxy 5=zyx
    JLabel rotationLabel[] = new JLabel[6];
    JTextField xValueField[] = new JTextField[6];
    JLabel xValueLabel[] = new JLabel[6];
    JTextField yValueField[] = new JTextField[6];
    JLabel yValueLabel[] = new JLabel[6];
    JTextField zValueField[] = new JTextField[6];
    JLabel zValueLabel[] = new JLabel[6];


    // Construct the frame
    public OrtViewRotationSettings(int rotationAngleW, int rotationAngleH, int rotationAngleZ, int rotationSequence)
    {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	    this.rotationAngleW = rotationAngleW;
	    this.rotationAngleH = rotationAngleH;
	    this.rotationAngleZ = rotationAngleZ;
		this.rotationSequence = rotationSequence; // 0=xyz 1=xzy 2=yxz 3=yzx 4=zxy 5=zyx
	    try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        pack();
    }





    /* Component initialization */
    private void jbInit() throws Exception
    {
        // buttons
        jButtonOK.addActionListener(this);
        jButtonCancel.addActionListener(this);

        Dimension tmpDim = new Dimension (4,2);


        // "angles" panels - set all properties common to all panels
		for (int i=0; i<6; i++)
        {
        // rotation Label
		rotationLabel[i] = new JLabel();
		rotationLabel[i].setHorizontalAlignment(SwingConstants.CENTER);
        rotationLabel[i].setHorizontalTextPosition(SwingConstants.CENTER);
        rotationLabel[i].setVerticalAlignment(SwingConstants.BOTTOM);
        rotationLabel[i].setVerticalTextPosition(SwingConstants.BOTTOM);
        rotationLabel[i].setText("Specify rotation angles (deg):");
		// x
		xValueField[i] = new JTextField();
        xValueField[i].setMaximumSize(tmpDim);
        xValueField[i].setMinimumSize(tmpDim);
        xValueField[i].setPreferredSize(tmpDim);
        xValueField[i].setText(String.valueOf(rotationAngleW));
        xValueField[i].setHorizontalAlignment(SwingConstants.RIGHT);
		xValueLabel[i] = new JLabel();
        xValueLabel[i].setHorizontalTextPosition(SwingConstants.CENTER);
        xValueLabel[i].setText("x(Sg)");
        xValueLabel[i].setVerticalAlignment(SwingConstants.TOP);
        // y
		yValueField[i] = new JTextField();
        yValueField[i].setMaximumSize(tmpDim);
        yValueField[i].setMinimumSize(tmpDim);
        yValueField[i].setPreferredSize(tmpDim);
        yValueField[i].setText(String.valueOf(rotationAngleH));
        yValueField[i].setHorizontalAlignment(SwingConstants.RIGHT);
		yValueLabel[i] = new JLabel();
        yValueLabel[i].setHorizontalTextPosition(SwingConstants.CENTER);
        yValueLabel[i].setText("y(Cr)");
        yValueLabel[i].setVerticalAlignment(SwingConstants.TOP);
        // z
		zValueField[i] = new JTextField();
        zValueField[i].setMaximumSize(tmpDim);
        zValueField[i].setMinimumSize(tmpDim);
        zValueField[i].setPreferredSize(tmpDim);
        zValueField[i].setText(String.valueOf(rotationAngleZ));
        zValueField[i].setHorizontalAlignment(SwingConstants.RIGHT);
		zValueLabel[i] = new JLabel();
        zValueLabel[i].setHorizontalTextPosition(SwingConstants.CENTER);
        zValueLabel[i].setText("z(Tx)");
        zValueLabel[i].setVerticalAlignment(SwingConstants.TOP);
        // panel
		anglesPanels[i] = new JPanel();
        anglesPanels[i].setLayout(new GridBagLayout());
        anglesPanels[i].add(rotationLabel[i], new GridBagConstraints(0, 0, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		}



        // "angles" panels - set all properties specific to each single panel,
		// namely, order of rotation

		// xyz
        xValueLabel[0].setHorizontalAlignment(SwingConstants.RIGHT);
        yValueLabel[0].setHorizontalAlignment(SwingConstants.CENTER);
        zValueLabel[0].setHorizontalAlignment(SwingConstants.LEFT);
        anglesPanels[0].add(xValueField[0], new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[0].add(xValueLabel[0], new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[0].add(yValueField[0], new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[0].add(yValueLabel[0], new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[0].add(zValueField[0], new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[0].add(zValueLabel[0], new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		// xzy
        xValueLabel[1].setHorizontalAlignment(SwingConstants.RIGHT);
        zValueLabel[1].setHorizontalAlignment(SwingConstants.CENTER);
        yValueLabel[1].setHorizontalAlignment(SwingConstants.LEFT);
        anglesPanels[1].add(xValueField[1], new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[1].add(xValueLabel[1], new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[1].add(zValueField[1], new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[1].add(zValueLabel[1], new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[1].add(yValueField[1], new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[1].add(yValueLabel[1], new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		// yxz
        yValueLabel[2].setHorizontalAlignment(SwingConstants.RIGHT);
        xValueLabel[2].setHorizontalAlignment(SwingConstants.CENTER);
        zValueLabel[2].setHorizontalAlignment(SwingConstants.LEFT);
        anglesPanels[2].add(yValueField[2], new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[2].add(yValueLabel[2], new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[2].add(xValueField[2], new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[2].add(xValueLabel[2], new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[2].add(zValueField[2], new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[2].add(zValueLabel[2], new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		// yzx
        yValueLabel[3].setHorizontalAlignment(SwingConstants.RIGHT);
        zValueLabel[3].setHorizontalAlignment(SwingConstants.CENTER);
        xValueLabel[3].setHorizontalAlignment(SwingConstants.LEFT);
        anglesPanels[3].add(yValueField[3], new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[3].add(yValueLabel[3], new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[3].add(zValueField[3], new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[3].add(zValueLabel[3], new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[3].add(xValueField[3], new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[3].add(xValueLabel[3], new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		// zxy
        zValueLabel[4].setHorizontalAlignment(SwingConstants.RIGHT);
        xValueLabel[4].setHorizontalAlignment(SwingConstants.CENTER);
        yValueLabel[4].setHorizontalAlignment(SwingConstants.LEFT);
        anglesPanels[4].add(zValueField[4], new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[4].add(zValueLabel[4], new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[4].add(xValueField[4], new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[4].add(xValueLabel[4], new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[4].add(yValueField[4], new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[4].add(yValueLabel[4], new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		// zyx
        zValueLabel[5].setHorizontalAlignment(SwingConstants.RIGHT);
        yValueLabel[5].setHorizontalAlignment(SwingConstants.CENTER);
        xValueLabel[5].setHorizontalAlignment(SwingConstants.LEFT);
        anglesPanels[5].add(zValueField[5], new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[5].add(zValueLabel[5], new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[5].add(yValueField[5], new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[5].add(yValueLabel[5], new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        anglesPanels[5].add(xValueField[5], new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        anglesPanels[5].add(xValueLabel[5], new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));



        this.setTitle("Rotation Settings...");
        setResizable(false);
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new GridBagLayout());



	    // Main Panel
	    // "angles" Section
		anglesTPane.insertTab("xyz", null, anglesPanels[0], "xyz", 0);
		anglesTPane.insertTab("xzy", null, anglesPanels[1], "xzy", 1);
		anglesTPane.insertTab("yxz", null, anglesPanels[2], "yxz", 2);
		anglesTPane.insertTab("yzx", null, anglesPanels[3], "yzx", 3);
		anglesTPane.insertTab("zxy", null, anglesPanels[4], "zxy", 4);
		anglesTPane.insertTab("zyx", null, anglesPanels[5], "zyx", 5);
		anglesTPane.setSelectedIndex(rotationSequence);
		anglesTPane.addChangeListener(new ChangeListener (){
		      public void stateChanged(ChangeEvent e)
			  {    rotationSequence = anglesTPane.getSelectedIndex();}
			  });
        contentPane.add(anglesTPane, new GridBagConstraints(0, 0, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 15, 0), 81, 13));
	    // buttons
        contentPane.add(jButtonOK, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 15, 15), 0, 0));
        contentPane.add(jButtonCancel, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 15, 15, 0), 0, 0));

        this.getContentPane().add(contentPane, null);
		getRootPane().setDefaultButton(jButtonOK);

    }







    /* Overridden so that we can exit when window is closed */
    protected void processWindowEvent(WindowEvent e)
    {
        if (e.getID() == WindowEvent.WINDOW_CLOSING)
           dispose();
        super.processWindowEvent(e);
    }



    public void actionPerformed(ActionEvent e)
    {   if (e.getSource() == jButtonOK)
        {   // first check all user input!
            if (!check_x())
                return;
            if (!check_y())
                return;
            if (!check_z())
                return;
            // if all checking is OK, pass e.th. to the parent
		    rotationAngleW *= -1; // "-" means that dialog box is returned through OK
            dispose();
        }
        else if (e.getSource() == jButtonCancel)
        {   // dispose without passing over any value
            dispose();
        }

        else if (e.getSource() == xValueField[rotationSequence])
        {   check_x();
            xValueField[rotationSequence].setText(String.valueOf(rotationAngleW));
        }
        else if (e.getSource() == yValueField[rotationSequence])
        {   check_y();
            yValueField[rotationSequence].setText(String.valueOf(rotationAngleH));
        }
        else if (e.getSource() == zValueField[rotationSequence])
        {   check_z();
            zValueField[rotationSequence].setText(String.valueOf(rotationAngleZ));
        }
    }


    // spell checking of the xValueField input
    private boolean check_x()
    {   try
        {   Integer tmp = Integer.valueOf(xValueField[rotationSequence].getText());
            rotationAngleW = tmp.intValue();
			if (rotationAngleW > 0) rotationAngleW = rotationAngleW % 360;
			else while (rotationAngleW < 0) rotationAngleW += 360;
            return(true);
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR rotation angle around x axis must be an integer!");
            return(false);
        }
    }




    // spell checking of the yValueField input
    private boolean check_y()
    {   try
        {   Integer tmp = Integer.valueOf(yValueField[rotationSequence].getText());
            rotationAngleH = tmp.intValue();
			if (rotationAngleH > 0) rotationAngleH = rotationAngleH % 360;
			else while (rotationAngleH < 0) rotationAngleH += 360;
            return(true);
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR rotation angle around y axis must be an integer!");
            return(false);
        }
    }


    // spell checking of the zValueField input
    private boolean check_z()
    {   try
        {   Integer tmp = Integer.valueOf(zValueField[rotationSequence].getText());
            rotationAngleZ = tmp.intValue();
			if (rotationAngleZ > 0) rotationAngleZ = rotationAngleZ % 360;
			else while (rotationAngleZ < 0) rotationAngleZ += 360;
            return(true);
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR rotation angle around z axis must be an integer!");
            return(false);
        }
    }



}   // end of class OrtViewRotationSettings




// ===========================================================
// -----------------------------------------------------------

// Class OrtViewCrosshairSettings
// Popup Frame to set the Crosshair location




class OrtViewCrosshairSettings extends JDialog implements ActionListener
{
    int wCurr, hCurr, zCurr;
    int w,h,z;

    // Three buttons
    JButton jButtonCenter = new JButton();
    JButton jButtonOK = new JButton();
    JButton jButtonCancel = new JButton();
    // "Exact Location" section
    JPanel voxelDimPanel = new JPanel();
    JLabel ExtLocationLabel = new JLabel();
    JTextField xValueField = new JTextField();
    JLabel xValueLabel = new JLabel();
    JTextField yValueField = new JTextField();
    JLabel yValueLabel = new JLabel();
    JTextField zValueField = new JTextField();
    JLabel zValueLabel = new JLabel();



    /* Construct the frame */
    public OrtViewCrosshairSettings(int wCurr, int hCurr, int zCurr, int w, int h, int zCorr)
    {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	    this.wCurr = wCurr;
	    this.hCurr = hCurr;
	    this.zCurr = zCurr;
        this.w = w;
        this.h = h;
        this.z = zCorr;
	    try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        pack();
if (jButtonOK.isDefaultButton()) IJ.write ("OK, sono il def!"); else IJ.write ("cacca OK, non lo sono!");
if (jButtonCenter.isDefaultButton()) IJ.write ("Center, sono il def!"); else IJ.write ("cacca Center, non lo sono!");
    }





    /* Component initialization */
    private void jbInit() throws Exception
    {
        //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame3.class.getResource("[Your Icon]")));

        // buttons
        jButtonCenter.setHorizontalTextPosition(SwingConstants.CENTER);
        jButtonCenter.setText("Center");
        jButtonCenter.addActionListener(this);
        jButtonOK.setHorizontalTextPosition(SwingConstants.CENTER);
        jButtonOK.setText("OK");
        jButtonOK.addActionListener(this);
        jButtonCancel.setHorizontalTextPosition(SwingConstants.CENTER);
        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(this);

        // "Exact Location" Section
        ExtLocationLabel.setHorizontalAlignment(SwingConstants.CENTER);
        ExtLocationLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        ExtLocationLabel.setVerticalAlignment(SwingConstants.BOTTOM);
        ExtLocationLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
        ExtLocationLabel.setText("Exact Location");
        Dimension tmpDim = new Dimension (4,2);
        // x
        xValueField.setMaximumSize(tmpDim);
        xValueField.setMinimumSize(tmpDim);
        xValueField.setPreferredSize(tmpDim);
        xValueField.setText(String.valueOf(wCurr));
        xValueField.setHorizontalAlignment(SwingConstants.RIGHT);
        xValueLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        xValueLabel.setText("x    ");
        xValueLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        xValueLabel.setVerticalAlignment(SwingConstants.TOP);
        // y
        yValueField.setMaximumSize(tmpDim);
        yValueField.setMinimumSize(tmpDim);
        yValueField.setPreferredSize(tmpDim);
        yValueField.setText(String.valueOf(hCurr));
        yValueField.setHorizontalAlignment(SwingConstants.RIGHT);
        yValueLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        yValueLabel.setText("y");
        yValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        yValueLabel.setVerticalAlignment(SwingConstants.TOP);
        // z
        zValueField.setMaximumSize(tmpDim);
        zValueField.setMinimumSize(tmpDim);
        zValueField.setPreferredSize(tmpDim);
        zValueField.setText(String.valueOf(zCurr));
        zValueField.setHorizontalAlignment(SwingConstants.RIGHT);
        zValueLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        zValueLabel.setText("    z");
        zValueLabel.setHorizontalAlignment(SwingConstants.LEFT);
        zValueLabel.setVerticalAlignment(SwingConstants.TOP);
        // panel
        voxelDimPanel.setLayout(new GridBagLayout());
        voxelDimPanel.add(ExtLocationLabel, new GridBagConstraints(0, 0, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        voxelDimPanel.add(xValueField, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        voxelDimPanel.add(xValueLabel, new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        voxelDimPanel.add(yValueField, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        voxelDimPanel.add(yValueLabel, new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        voxelDimPanel.add(zValueField, new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 25, 20));
        voxelDimPanel.add(zValueLabel, new GridBagConstraints(2, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        this.setTitle("Crosshair Location Settings...");
        setResizable(false);
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new GridBagLayout());



	    // Main Panel
	    // "Exact Location" Section
        contentPane.add(voxelDimPanel, new GridBagConstraints(0, 1, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 15, 0), 81, 13));
	    // buttons
        contentPane.add(jButtonOK, new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 15, 15, 0), 0, 0));
        contentPane.add(jButtonCancel, new GridBagConstraints(1, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 15, 15), 0, 0));
        contentPane.add(jButtonCenter, new GridBagConstraints(0, 0, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 0, 0, 0), 0, 0));

		  getRootPane().setContentPane(contentPane);
		  getRootPane().setDefaultButton(jButtonOK);
    }







    /* Overridden so we can exit when window is closed */
    protected void processWindowEvent(WindowEvent e)
    {
        if (e.getID() == WindowEvent.WINDOW_CLOSING)
           dispose();
        super.processWindowEvent(e);
    }





    public void actionPerformed(ActionEvent e)
    {   if (e.getSource() == jButtonOK)
        {   // first check all user input!
            if (!check_x())
                return;
            if (!check_y())
                return;
            if (!check_z())
                return;
            // if all checking is OK, pass e.th. to the parent
		    wCurr *= -1; // "-" means that dialog box is returned through OK
            dispose();
        }
        else if (e.getSource() == jButtonCancel)
        {   // dispose without passing over any value
            dispose();
        }

        else if (e.getSource() == jButtonCenter)
	    {   wCurr = (int)(w/2);
		    hCurr = (int)(h/2);
		    zCurr = (int)(z/2);
            xValueField.setText(String.valueOf(wCurr));
            yValueField.setText(String.valueOf(hCurr));
            zValueField.setText(String.valueOf(zCurr));
	    }
        else if (e.getSource() == xValueField)
            check_x();
        else if (e.getSource() == yValueField)
            check_y();
        else if (e.getSource() == zValueField)
            check_z();

    }


    // spell checking of the xValueField input
    private boolean check_x()
    {   try
        {   Integer tmp = Integer.valueOf(xValueField.getText());
            if (tmp.intValue() <= 0)
            {   IJ.error("ERROR x coordinate must be at least 1!");
                return(false);
            }
            else if (tmp.intValue() > w)
            {   IJ.error("ERROR x coordinate must be smaller than "+(w+1)+"!");
                return(false);
            }
            else
            {   wCurr = tmp.intValue();
                return(true);
            }
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR x coordinate must be an integer!");
            return(false);
        }
    }




    // spell checking of the yValueField input
    private boolean check_y()
    {   try
        {   Integer tmp = Integer.valueOf(yValueField.getText());
            if (tmp.intValue() <= 0)
            {   IJ.error("ERROR y coordinate must be at least 1!");
                return(false);
            }
            else if (tmp.intValue() > h)
            {   IJ.error("ERROR y coordinate must be smaller than "+(h+1)+"!");
                return(false);
            }
            else
            {   hCurr = tmp.intValue();
                return(true);
            }
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR y coordinate must be an integer!");
            return(false);
        }
    }


    // spell checking of the zValueField input
    private boolean check_z()
    {   try
        {   Integer tmp = Integer.valueOf(zValueField.getText());
            if (tmp.intValue() <= 0)
            {   IJ.error("ERROR z coordinate must be at least 1!");
                return(false);
            }
            else if (tmp.intValue() > z)
            {   IJ.error("ERROR z coordinate must be smaller than "+(z+1)+"!");
                return(false);
            }
            else
            {   zCurr = tmp.intValue();
                return(true);
            }
        }
        catch (NumberFormatException ne)
        {   IJ.error ("ERROR z coordinate must be an integer!");
            return(false);
        }
    }


}